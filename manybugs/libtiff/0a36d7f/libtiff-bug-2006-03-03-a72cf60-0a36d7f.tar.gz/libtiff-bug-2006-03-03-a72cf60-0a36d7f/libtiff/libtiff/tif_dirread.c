struct _IO_FILE;
struct _IO_FILE *_coverage_fout  ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
enum TIFFIgnoreSense {
    TIS_STORE = 0,
    TIS_EXTRACT = 1,
    TIS_EMPTY = 2
} ;
struct __anonstruct_TIFFHeader_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeader_18 TIFFHeader;
struct __anonstruct_TIFFDirEntry_19 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint32 tdir_count ;
   uint32 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_19 TIFFDirEntry;
enum __anonenum_TIFFDataType_20 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13
} ;
typedef enum __anonenum_TIFFDataType_20 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrip_t;
typedef uint32 ttile_t;
typedef int32 tsize_t;
typedef void *tdata_t;
typedef uint32 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_21 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_21 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_22 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_22 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_23 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_23 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_24 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_24 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_25 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_25 TIFFCodec;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_27 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_26 {
   int __count ;
   union __anonunion___value_27 __value ;
};
typedef struct __anonstruct___mbstate_t_26 __mbstate_t;
struct __anonstruct__G_fpos_t_28 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_28 _G_fpos_t;
struct __anonstruct__G_fpos64_t_29 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_29 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tsize_t (*TIFFReadWriteProc)(thandle_t  , tdata_t  , tsize_t  );
typedef toff_t (*TIFFSeekProc)(thandle_t  , toff_t  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef toff_t (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , tdata_t * , toff_t * );
typedef void (*TIFFUnmapFileProc)(thandle_t  , tdata_t  , toff_t  );
typedef void (*TIFFExtendProc)(TIFF * );
struct __anonstruct_TIFFFieldInfo_30 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_30 TIFFFieldInfo;
struct _TIFFTagValue {
   TIFFFieldInfo const   *info ;
   int count ;
   void *value ;
};
typedef struct _TIFFTagValue TIFFTagValue;
typedef int (*TIFFVSetMethod)(TIFF * , ttag_t  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , ttag_t  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , ttag_t  , va_list  ) ;
   int (*vgetfield)(TIFF * , ttag_t  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFDirectory_32 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   tstrip_t td_stripsperimage ;
   tstrip_t td_nstrips ;
   uint32 *td_stripoffset ;
   uint32 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint32 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_32 TIFFDirectory;
typedef double dblparam_t;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , tsample_t  );
typedef int (*TIFFCodeMethod)(TIFF * , tidata_t  , tsize_t  , tsample_t  );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF * , tidata_t  , tsize_t  );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   toff_t tif_diroff ;
   toff_t tif_nextdiroff ;
   toff_t *tif_dirlist ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFHeader tif_header ;
   int const   *tif_typeshift ;
   long const   *tif_typemask ;
   uint32 tif_row ;
   tdir_t tif_curdir ;
   tstrip_t tif_curstrip ;
   toff_t tif_curoff ;
   toff_t tif_dataoff ;
   uint16 tif_nsubifd ;
   toff_t tif_subifdoff ;
   uint32 tif_col ;
   ttile_t tif_curtile ;
   tsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , tsample_t  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , tsample_t  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encoderow)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_decodestrip)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encodestrip)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_decodetile)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   int (*tif_encodetile)(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   tidata_t tif_data ;
   tsize_t tif_scanlinesize ;
   tsize_t tif_scanlineskew ;
   tidata_t tif_rawdata ;
   tsize_t tif_rawdatasize ;
   tidata_t tif_rawcp ;
   tsize_t tif_rawcc ;
   tidata_t tif_base ;
   toff_t tif_size ;
   int (*tif_mapproc)(thandle_t  , tdata_t * , toff_t * ) ;
   void (*tif_unmapproc)(thandle_t  , tdata_t  , toff_t  ) ;
   thandle_t tif_clientdata ;
   tsize_t (*tif_readproc)(thandle_t  , tdata_t  , tsize_t  ) ;
   tsize_t (*tif_writeproc)(thandle_t  , tdata_t  , tsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF * , tidata_t  , tsize_t  ) ;
   TIFFFieldInfo **tif_fieldinfo ;
   size_t tif_nfields ;
   TIFFFieldInfo const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
extern FILE *fopen(char const   * __restrict  __filename ,
                   char const   * __restrict  __modes )  __asm__("fopen64")  ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int fflush(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  }
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  }
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  }
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "8\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "9\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "5\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        {
        fprintf(_coverage_fout, "4\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "16\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "17\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "13\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        fprintf(_coverage_fout, "12\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          fprintf(_coverage_fout, "11\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "25\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "22\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        fprintf(_coverage_fout, "21\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          fprintf(_coverage_fout, "20\n");
          fflush(_coverage_fout);
          }
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            {
            fprintf(_coverage_fout, "19\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "31\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "32\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "29\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      {
      fprintf(_coverage_fout, "28\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "30\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "33\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      fprintf(_coverage_fout, "34\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "36\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        fprintf(_coverage_fout, "35\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
    }
    {
    fprintf(_coverage_fout, "38\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "41\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      fprintf(_coverage_fout, "42\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "46\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        fprintf(_coverage_fout, "43\n");
        fflush(_coverage_fout);
        }

      } else {
        {
        fprintf(_coverage_fout, "45\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          {
          fprintf(_coverage_fout, "44\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      }
    }
    {
    fprintf(_coverage_fout, "48\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "51\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*__s != 0) {
      {
      fprintf(_coverage_fout, "54\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        fprintf(_coverage_fout, "53\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          fprintf(_coverage_fout, "52\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  }
  if ((int const   )*__s == 0) {
    {
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((void *)0);
  } else {
    {
    fprintf(_coverage_fout, "58\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((unsigned int )__s);
  }
  {
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "66\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*__s != 0) {
      {
      fprintf(_coverage_fout, "65\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        fprintf(_coverage_fout, "64\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          fprintf(_coverage_fout, "63\n");
          fflush(_coverage_fout);
          }
          if ((int const   )*__s != (int const   )__accept3) {
            {
            fprintf(_coverage_fout, "62\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "67\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  }
  if ((int const   )*__s == 0) {
    {
    fprintf(_coverage_fout, "68\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((void *)0);
  } else {
    {
    fprintf(_coverage_fout, "69\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((unsigned int )__s);
  }
  {
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "90\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "73\n");
    fflush(_coverage_fout);
    }
    __s = *__nextp;
  } else {
    {
    fprintf(_coverage_fout, "74\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "91\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    }
    if ((int )*__s == (int )__sep) {
      {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "92\n");
  fflush(_coverage_fout);
  }
  __result = (char *)((void *)0);
  {
  fprintf(_coverage_fout, "93\n");
  fflush(_coverage_fout);
  }
  if ((int )*__s != 0) {
    {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    }
    tmp = __s;
    {
    fprintf(_coverage_fout, "86\n");
    fflush(_coverage_fout);
    }
    __s ++;
    {
    fprintf(_coverage_fout, "87\n");
    fflush(_coverage_fout);
    }
    __result = tmp;
    {
    fprintf(_coverage_fout, "88\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "81\n");
      fflush(_coverage_fout);
      }
      if ((int )*__s != 0) {
        {
        fprintf(_coverage_fout, "78\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "82\n");
      fflush(_coverage_fout);
      }
      tmp___0 = __s;
      {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      }
      __s ++;
      {
      fprintf(_coverage_fout, "84\n");
      fflush(_coverage_fout);
      }
      if ((int )*tmp___0 == (int )__sep) {
        {
        fprintf(_coverage_fout, "79\n");
        fflush(_coverage_fout);
        }
        *(__s + -1) = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "80\n");
        fflush(_coverage_fout);
        }

      }
    }
  } else {
    {
    fprintf(_coverage_fout, "89\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "94\n");
  fflush(_coverage_fout);
  }
  *__nextp = __s;
  {
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "105\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "106\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    }
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    {
    fprintf(_coverage_fout, "101\n");
    fflush(_coverage_fout);
    }
    tmp___0 = tmp___2;
    {
    fprintf(_coverage_fout, "102\n");
    fflush(_coverage_fout);
    }
    *__s = tmp___0;
    {
    fprintf(_coverage_fout, "103\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "96\n");
      fflush(_coverage_fout);
      }
      tmp = *__s;
      {
      fprintf(_coverage_fout, "97\n");
      fflush(_coverage_fout);
      }
      (*__s) ++;
      {
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);
      }
      *tmp = (char )'\000';
    } else {
      {
      fprintf(_coverage_fout, "99\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "104\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "107\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "125\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "126\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "121\n");
    fflush(_coverage_fout);
    }
    __cp = __retval;
    {
    fprintf(_coverage_fout, "122\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "118\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == 0) {
        {
        fprintf(_coverage_fout, "108\n");
        fflush(_coverage_fout);
        }
        __cp = (char *)((void *)0);
        break;
      } else {
        {
        fprintf(_coverage_fout, "109\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "119\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == (int )__reject1) {
        {
        fprintf(_coverage_fout, "110\n");
        fflush(_coverage_fout);
        }
        tmp = __cp;
        {
        fprintf(_coverage_fout, "111\n");
        fflush(_coverage_fout);
        }
        __cp ++;
        {
        fprintf(_coverage_fout, "112\n");
        fflush(_coverage_fout);
        }
        *tmp = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "117\n");
        fflush(_coverage_fout);
        }
        if ((int )*__cp == (int )__reject2) {
          {
          fprintf(_coverage_fout, "113\n");
          fflush(_coverage_fout);
          }
          tmp = __cp;
          {
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);
          }
          __cp ++;
          {
          fprintf(_coverage_fout, "115\n");
          fflush(_coverage_fout);
          }
          *tmp = (char )'\000';
          break;
        } else {
          {
          fprintf(_coverage_fout, "116\n");
          fflush(_coverage_fout);
          }

        }
      }
      {
      fprintf(_coverage_fout, "120\n");
      fflush(_coverage_fout);
      }
      __cp ++;
    }
    {
    fprintf(_coverage_fout, "123\n");
    fflush(_coverage_fout);
    }
    *__s = __cp;
  } else {
    {
    fprintf(_coverage_fout, "124\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "127\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "149\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "150\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "145\n");
    fflush(_coverage_fout);
    }
    __cp = __retval;
    {
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "142\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == 0) {
        {
        fprintf(_coverage_fout, "128\n");
        fflush(_coverage_fout);
        }
        __cp = (char *)((void *)0);
        break;
      } else {
        {
        fprintf(_coverage_fout, "129\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "143\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == (int )__reject1) {
        {
        fprintf(_coverage_fout, "130\n");
        fflush(_coverage_fout);
        }
        tmp = __cp;
        {
        fprintf(_coverage_fout, "131\n");
        fflush(_coverage_fout);
        }
        __cp ++;
        {
        fprintf(_coverage_fout, "132\n");
        fflush(_coverage_fout);
        }
        *tmp = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "141\n");
        fflush(_coverage_fout);
        }
        if ((int )*__cp == (int )__reject2) {
          {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          }
          tmp = __cp;
          {
          fprintf(_coverage_fout, "134\n");
          fflush(_coverage_fout);
          }
          __cp ++;
          {
          fprintf(_coverage_fout, "135\n");
          fflush(_coverage_fout);
          }
          *tmp = (char )'\000';
          break;
        } else {
          {
          fprintf(_coverage_fout, "140\n");
          fflush(_coverage_fout);
          }
          if ((int )*__cp == (int )__reject3) {
            {
            fprintf(_coverage_fout, "136\n");
            fflush(_coverage_fout);
            }
            tmp = __cp;
            {
            fprintf(_coverage_fout, "137\n");
            fflush(_coverage_fout);
            }
            __cp ++;
            {
            fprintf(_coverage_fout, "138\n");
            fflush(_coverage_fout);
            }
            *tmp = (char )'\000';
            break;
          } else {
            {
            fprintf(_coverage_fout, "139\n");
            fflush(_coverage_fout);
            }

          }
        }
      }
      {
      fprintf(_coverage_fout, "144\n");
      fflush(_coverage_fout);
      }
      __cp ++;
    }
    {
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    }
    *__s = __cp;
  } else {
    {
    fprintf(_coverage_fout, "148\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "151\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "152\n");
  fflush(_coverage_fout);
  }
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  {
  fprintf(_coverage_fout, "153\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "154\n");
  fflush(_coverage_fout);
  }
  tmp = _IO_getc(stdin);
  {
  fprintf(_coverage_fout, "155\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(__fp);
    {
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);
    }
    (__fp->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "160\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "169\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "170\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "164\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(__fp);
    {
    fprintf(_coverage_fout, "165\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "166\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "167\n");
    fflush(_coverage_fout);
    }
    (__fp->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "168\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "171\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "178\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(stdin);
    {
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);
    }
    tmp___1 = stdin->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "175\n");
    fflush(_coverage_fout);
    }
    (stdin->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "176\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "179\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "180\n");
  fflush(_coverage_fout);
  }
  tmp = _IO_putc(__c, stdout);
  {
  fprintf(_coverage_fout, "181\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "189\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "190\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "182\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "183\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "184\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "185\n");
    fflush(_coverage_fout);
    }
    (__stream->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "186\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "187\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "188\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "191\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "199\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "200\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "195\n");
    fflush(_coverage_fout);
    }
    (__stream->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "196\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "197\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "198\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "201\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "209\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "210\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "202\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "203\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "204\n");
    fflush(_coverage_fout);
    }
    tmp___1 = stdout->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "205\n");
    fflush(_coverage_fout);
    }
    (stdout->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "206\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "207\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "208\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "211\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "212\n");
  fflush(_coverage_fout);
  }
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "213\n");
  fflush(_coverage_fout);
  }
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern tdata_t _TIFFmalloc(tsize_t  ) ;
extern tdata_t _TIFFrealloc(tdata_t  , tsize_t  ) ;
extern void _TIFFmemset(tdata_t  , int  , tsize_t  ) ;
extern void _TIFFmemcpy(tdata_t  , tdata_t  , tsize_t  ) ;
extern int _TIFFmemcmp(tdata_t  , tdata_t  , tsize_t  ) ;
extern void _TIFFfree(tdata_t  ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern ttag_t TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern void TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , int  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , ttag_t  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFieldWithTag(TIFF * , ttag_t  ) ;
extern TIFFFieldInfo const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF * ) ;
extern void TIFFClose(TIFF * ) ;
extern int TIFFFlush(TIFF * ) ;
extern int TIFFFlushData(TIFF * ) ;
extern int TIFFGetField(TIFF * , ttag_t   , ...) ;
extern int TIFFVGetField(TIFF * , ttag_t  , va_list  ) ;
extern int TIFFGetFieldDefaulted(TIFF * , ttag_t   , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF * , ttag_t  , va_list  ) ;
int TIFFReadDirectory(TIFF *tif ) ;
int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                            TIFFFieldInfo const   *info , size_t n ) ;
int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) ;
extern tsize_t TIFFScanlineSize(TIFF * ) ;
extern tsize_t TIFFRasterScanlineSize(TIFF * ) ;
extern tsize_t TIFFStripSize(TIFF * ) ;
extern tsize_t TIFFRawStripSize(TIFF * , tstrip_t  ) ;
extern tsize_t TIFFVStripSize(TIFF * , uint32  ) ;
extern tsize_t TIFFTileRowSize(TIFF * ) ;
extern tsize_t TIFFTileSize(TIFF * ) ;
extern tsize_t TIFFVTileSize(TIFF * , uint32  ) ;
extern uint32 TIFFDefaultStripSize(TIFF * , uint32  ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern tdir_t TIFFCurrentDirectory(TIFF * ) ;
extern tdir_t TIFFNumberOfDirectories(TIFF * ) ;
extern uint32 TIFFCurrentDirOffset(TIFF * ) ;
extern tstrip_t TIFFCurrentStrip(TIFF * ) ;
extern ttile_t TIFFCurrentTile(TIFF * ) ;
extern int TIFFReadBufferSetup(TIFF * , tdata_t  , tsize_t  ) ;
extern int TIFFWriteBufferSetup(TIFF * , tdata_t  , tsize_t  ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , tdir_t  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint32  ) ;
extern int TIFFUnlinkDirectory(TIFF * , tdir_t  ) ;
extern int TIFFSetField(TIFF * , ttag_t   , ...) ;
extern int TIFFVSetField(TIFF * , ttag_t  , va_list  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern int TIFFReassignTagToIgnore(enum TIFFIgnoreSense  , int  ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF * , tdata_t  , uint32  , tsample_t  ) ;
extern int TIFFWriteScanline(TIFF * , tdata_t  , uint32  , tsample_t  ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , tstrip_t  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tsize_t (*)(thandle_t  , tdata_t  , tsize_t  ) ,
                            tsize_t (*)(thandle_t  , tdata_t  , tsize_t  ) ,
                            toff_t (*)(thandle_t  , toff_t  , int  ) ,
                            int (*)(thandle_t  ) , toff_t (*)(thandle_t  ) ,
                            int (*)(thandle_t  , tdata_t * , toff_t * ) ,
                            void (*)(thandle_t  , tdata_t  , toff_t  ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern ttile_t TIFFComputeTile(TIFF * , uint32  , uint32  , uint32  ,
                               tsample_t  ) ;
extern int TIFFCheckTile(TIFF * , uint32  , uint32  , uint32  , tsample_t  ) ;
extern ttile_t TIFFNumberOfTiles(TIFF * ) ;
extern tsize_t TIFFReadTile(TIFF * , tdata_t  , uint32  , uint32  , uint32  ,
                            tsample_t  ) ;
extern tsize_t TIFFWriteTile(TIFF * , tdata_t  , uint32  , uint32  , uint32  ,
                             tsample_t  ) ;
extern tstrip_t TIFFComputeStrip(TIFF * , uint32  , tsample_t  ) ;
extern tstrip_t TIFFNumberOfStrips(TIFF * ) ;
extern tsize_t TIFFReadEncodedStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadRawStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadEncodedTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadRawTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteEncodedStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteRawStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteEncodedTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteRawTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF * , toff_t  ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 * , unsigned long  ) ;
extern void TIFFSwabArrayOfTriples(uint8 * , unsigned long  ) ;
extern void TIFFSwabArrayOfLong(uint32 * , unsigned long  ) ;
extern void TIFFSwabArrayOfDouble(double * , unsigned long  ) ;
extern void TIFFReverseBits(unsigned char * , unsigned long  ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern TIFFFieldInfo const   *_TIFFGetFieldInfo(size_t * ) ;
extern TIFFFieldInfo const   *_TIFFGetExifFieldInfo(size_t * ) ;
extern void _TIFFSetupFieldInfo(TIFF * , TIFFFieldInfo const   * , size_t  ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern TIFFDataType _TIFFSampleToTagType(TIFF * ) ;
extern TIFFFieldInfo const   *_TIFFFindOrRegisterFieldInfo(TIFF *tif ,
                                                           ttag_t tag ,
                                                           TIFFDataType dt ) ;
extern TIFFFieldInfo *_TIFFCreateAnonFieldInfo(TIFF *tif , ttag_t tag ,
                                               TIFFDataType dt ) ;
extern int _TIFFgetMode(char const   * , char const   * ) ;
extern int _TIFFNoRowEncode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern int _TIFFNoStripEncode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern int _TIFFNoTileEncode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern int _TIFFNoRowDecode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern int _TIFFNoStripDecode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern int _TIFFNoTileDecode(TIFF * , tidata_t  , tsize_t  , tsample_t  ) ;
extern void _TIFFNoPostDecode(TIFF * , tidata_t  , tsize_t  ) ;
extern int _TIFFNoPreCode(TIFF * , tsample_t  ) ;
extern int _TIFFNoSeek(TIFF * , uint32  ) ;
extern void _TIFFSwab16BitData(TIFF * , tidata_t  , tsize_t  ) ;
extern void _TIFFSwab24BitData(TIFF * , tidata_t  , tsize_t  ) ;
extern void _TIFFSwab32BitData(TIFF * , tidata_t  , tsize_t  ) ;
extern void _TIFFSwab64BitData(TIFF * , tidata_t  , tsize_t  ) ;
extern int TIFFFlushData1(TIFF * ) ;
extern int TIFFDefaultDirectory(TIFF * ) ;
extern int TIFFSetCompressionScheme(TIFF * , int  ) ;
extern int TIFFSetDefaultCompressionState(TIFF * ) ;
extern uint32 _TIFFDefaultStripSize(TIFF * , uint32  ) ;
extern void _TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int _TIFFDataSize(TIFFDataType  ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern tdata_t _TIFFCheckMalloc(TIFF * , size_t  , size_t  , char const   * ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) ;
static void MissingRequired(TIFF *tif , char const   *tagname ) ;
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) ;
static tsize_t TIFFFetchData(TIFF *tif , TIFFDirEntry *dir , char *cp ) ;
static tsize_t TIFFFetchString(TIFF *tif , TIFFDirEntry *dir , char *cp ) ;
static float TIFFFetchRational(TIFF *tif , TIFFDirEntry *dir ) ;
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp ) ;
static int TIFFFetchPerSampleShorts(TIFF *tif , TIFFDirEntry *dir , uint16 *pl ) ;
static int TIFFFetchPerSampleLongs(TIFF *tif , TIFFDirEntry *dir , uint32 *pl ) ;
static int TIFFFetchPerSampleAnys(TIFF *tif , TIFFDirEntry *dir , double *pl ) ;
static int TIFFFetchShortArray(TIFF *tif , TIFFDirEntry *dir , uint16 *v ) ;
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , long nstrips ,
                               uint32 **lpp ) ;
static int TIFFFetchRefBlackWhite(TIFF *tif , TIFFDirEntry *dir ) ;
static float TIFFFetchFloat(TIFF *tif , TIFFDirEntry *dir ) ;
static int TIFFFetchFloatArray(TIFF *tif , TIFFDirEntry *dir , float *v ) ;
static int TIFFFetchDoubleArray(TIFF *tif , TIFFDirEntry *dir , double *v ) ;
static int TIFFFetchAnyArray(TIFF *tif , TIFFDirEntry *dir , double *v ) ;
static int TIFFFetchShortPair(TIFF *tif , TIFFDirEntry *dir ) ;
static void ChopUpSingleUncompressedStrip(TIFF *tif ) ;
static char const   module[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
int TIFFReadDirectory(TIFF *tif ) 
{ int n ;
  TIFFDirectory *td ;
  TIFFDirEntry *dp ;
  TIFFDirEntry *dir ;
  uint16 iv ;
  uint32 v ;
  TIFFFieldInfo const   *fip ;
  size_t fix ;
  uint16 dircount ;
  toff_t nextdiroff ;
  int diroutoforderwarning ;
  toff_t *new_dirlist ;
  tdata_t tmp ;
  toff_t tmp___0 ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  tsize_t tmp___3 ;
  tsize_t tmp___4 ;
  toff_t off ;
  tdata_t tmp___5 ;
  int tmp___6 ;
  TIFFFieldInfo *tmp___7 ;
  uint32 expected ;
  unsigned int tmp___8 ;
  int tmp___9 ;
  unsigned long tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  unsigned long tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  double dv ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  char *cp ;
  int tmp___29 ;
  tdata_t tmp___30 ;
  uint32 c ;
  tsize_t tmp___31 ;
  unsigned long tmp___32 ;
  TIFFFieldInfo const   *tmp___33 ;
  int tmp___34 ;
  TIFFFieldInfo const   *tmp___35 ;
  int tmp___36 ;
  TIFFFieldInfo const   *tmp___37 ;
  int tmp___38 ;
  toff_t tmp___39 ;
  tsize_t tmp___40 ;
  tstrip_t strip ;
  tsize_t tmp___41 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "547\n");
  fflush(_coverage_fout);
  }
  dir = (TIFFDirEntry *)((void *)0);
  {
  fprintf(_coverage_fout, "548\n");
  fflush(_coverage_fout);
  }
  diroutoforderwarning = 0;
  {
  fprintf(_coverage_fout, "549\n");
  fflush(_coverage_fout);
  }
  tif->tif_diroff = tif->tif_nextdiroff;
  {
  fprintf(_coverage_fout, "550\n");
  fflush(_coverage_fout);
  }
  if (tif->tif_diroff == 0U) {
    {
    fprintf(_coverage_fout, "214\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "551\n");
  fflush(_coverage_fout);
  }
  n = 0;
  {
  fprintf(_coverage_fout, "552\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "219\n");
    fflush(_coverage_fout);
    }
    if (n < (int )tif->tif_dirnumber) {
      {
      fprintf(_coverage_fout, "216\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "220\n");
    fflush(_coverage_fout);
    }
    if (*(tif->tif_dirlist + n) == tif->tif_diroff) {
      {
      fprintf(_coverage_fout, "217\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "218\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "221\n");
    fflush(_coverage_fout);
    }
    n ++;
  }
  {
  fprintf(_coverage_fout, "553\n");
  fflush(_coverage_fout);
  }
  tif->tif_dirnumber = (uint16 )((int )tif->tif_dirnumber + 1);
  {
  fprintf(_coverage_fout, "554\n");
  fflush(_coverage_fout);
  }
  tmp = _TIFFrealloc((void *)tif->tif_dirlist,
                     (int )((unsigned int )tif->tif_dirnumber * sizeof(toff_t )));
  {
  fprintf(_coverage_fout, "555\n");
  fflush(_coverage_fout);
  }
  new_dirlist = (toff_t *)tmp;
  {
  fprintf(_coverage_fout, "556\n");
  fflush(_coverage_fout);
  }
  if (! new_dirlist) {
    {
    fprintf(_coverage_fout, "222\n");
    fflush(_coverage_fout);
    }
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: Failed to allocate space for IFD list", tif->tif_name);
    {
    fprintf(_coverage_fout, "223\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "224\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "557\n");
  fflush(_coverage_fout);
  }
  tif->tif_dirlist = new_dirlist;
  {
  fprintf(_coverage_fout, "558\n");
  fflush(_coverage_fout);
  }
  *(tif->tif_dirlist + ((int )tif->tif_dirnumber - 1)) = tif->tif_diroff;
  {
  fprintf(_coverage_fout, "559\n");
  fflush(_coverage_fout);
  }
  (*(tif->tif_cleanup))(tif);
  {
  fprintf(_coverage_fout, "560\n");
  fflush(_coverage_fout);
  }
  tif->tif_curdir = (tdir_t )((int )tif->tif_curdir + 1);
  {
  fprintf(_coverage_fout, "561\n");
  fflush(_coverage_fout);
  }
  nextdiroff = 0U;
  {
  fprintf(_coverage_fout, "562\n");
  fflush(_coverage_fout);
  }
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    {
    fprintf(_coverage_fout, "237\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
    {
    fprintf(_coverage_fout, "238\n");
    fflush(_coverage_fout);
    }
    if (tmp___0 == tif->tif_diroff) {
      {
      fprintf(_coverage_fout, "225\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "226\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Seek error accessing TIFF directory", tif->tif_name);
      {
      fprintf(_coverage_fout, "227\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
    {
    fprintf(_coverage_fout, "239\n");
    fflush(_coverage_fout);
    }
    tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)(& dircount),
                                     (int )sizeof(uint16 ));
    {
    fprintf(_coverage_fout, "240\n");
    fflush(_coverage_fout);
    }
    if (tmp___1 == (int )sizeof(uint16 )) {
      {
      fprintf(_coverage_fout, "228\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "229\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      {
      fprintf(_coverage_fout, "230\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
    {
    fprintf(_coverage_fout, "241\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "231\n");
      fflush(_coverage_fout);
      }
      TIFFSwabShort(& dircount);
    } else {
      {
      fprintf(_coverage_fout, "232\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "242\n");
    fflush(_coverage_fout);
    }
    tmp___2 = _TIFFCheckMalloc(tif, (unsigned int )dircount,
                               sizeof(TIFFDirEntry ), "to read TIFF directory");
    {
    fprintf(_coverage_fout, "243\n");
    fflush(_coverage_fout);
    }
    dir = (TIFFDirEntry *)tmp___2;
    {
    fprintf(_coverage_fout, "244\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "233\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "234\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "245\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)dir,
                                     (int )((unsigned int )dircount * sizeof(TIFFDirEntry )));
    {
    fprintf(_coverage_fout, "246\n");
    fflush(_coverage_fout);
    }
    if (tmp___3 == (int )((unsigned int )dircount * sizeof(TIFFDirEntry ))) {
      {
      fprintf(_coverage_fout, "235\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "236\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%.100s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    }
    {
    fprintf(_coverage_fout, "247\n");
    fflush(_coverage_fout);
    }
    tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                     (void *)(& nextdiroff),
                                     (int )sizeof(uint32 ));
  } else {
    {
    fprintf(_coverage_fout, "259\n");
    fflush(_coverage_fout);
    }
    off = tif->tif_diroff;
    {
    fprintf(_coverage_fout, "260\n");
    fflush(_coverage_fout);
    }
    if (off + sizeof(uint16 ) > tif->tif_size) {
      {
      fprintf(_coverage_fout, "248\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      {
      fprintf(_coverage_fout, "249\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "250\n");
      fflush(_coverage_fout);
      }
      _TIFFmemcpy((void *)(& dircount), (void *)(tif->tif_base + off),
                  (int )sizeof(uint16 ));
    }
    {
    fprintf(_coverage_fout, "261\n");
    fflush(_coverage_fout);
    }
    off += sizeof(uint16 );
    {
    fprintf(_coverage_fout, "262\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "251\n");
      fflush(_coverage_fout);
      }
      TIFFSwabShort(& dircount);
    } else {
      {
      fprintf(_coverage_fout, "252\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "263\n");
    fflush(_coverage_fout);
    }
    tmp___5 = _TIFFCheckMalloc(tif, (unsigned int )dircount,
                               sizeof(TIFFDirEntry ), "to read TIFF directory");
    {
    fprintf(_coverage_fout, "264\n");
    fflush(_coverage_fout);
    }
    dir = (TIFFDirEntry *)tmp___5;
    {
    fprintf(_coverage_fout, "265\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "253\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "254\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "266\n");
    fflush(_coverage_fout);
    }
    if (off + (unsigned int )dircount * sizeof(TIFFDirEntry ) > tif->tif_size) {
      {
      fprintf(_coverage_fout, "255\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "256\n");
      fflush(_coverage_fout);
      }
      _TIFFmemcpy((void *)dir, (void *)(tif->tif_base + off),
                  (int )((unsigned int )dircount * sizeof(TIFFDirEntry )));
    }
    {
    fprintf(_coverage_fout, "267\n");
    fflush(_coverage_fout);
    }
    off += (unsigned int )dircount * sizeof(TIFFDirEntry );
    {
    fprintf(_coverage_fout, "268\n");
    fflush(_coverage_fout);
    }
    if (off + sizeof(uint32 ) <= tif->tif_size) {
      {
      fprintf(_coverage_fout, "257\n");
      fflush(_coverage_fout);
      }
      _TIFFmemcpy((void *)(& nextdiroff), (void *)(tif->tif_base + off),
                  (int )sizeof(uint32 ));
    } else {
      {
      fprintf(_coverage_fout, "258\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "563\n");
  fflush(_coverage_fout);
  }
  if (tif->tif_flags & 128U) {
    {
    fprintf(_coverage_fout, "269\n");
    fflush(_coverage_fout);
    }
    TIFFSwabLong(& nextdiroff);
  } else {
    {
    fprintf(_coverage_fout, "270\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "564\n");
  fflush(_coverage_fout);
  }
  tif->tif_nextdiroff = nextdiroff;
  {
  fprintf(_coverage_fout, "565\n");
  fflush(_coverage_fout);
  }
  tif->tif_flags &= 4294967231U;
  {
  fprintf(_coverage_fout, "566\n");
  fflush(_coverage_fout);
  }
  td = & tif->tif_dir;
  {
  fprintf(_coverage_fout, "567\n");
  fflush(_coverage_fout);
  }
  TIFFFreeDirectory(tif);
  {
  fprintf(_coverage_fout, "568\n");
  fflush(_coverage_fout);
  }
  TIFFDefaultDirectory(tif);
  {
  fprintf(_coverage_fout, "569\n");
  fflush(_coverage_fout);
  }
  TIFFSetField(tif, 284U, 1);
  {
  fprintf(_coverage_fout, "570\n");
  fflush(_coverage_fout);
  }
  dp = dir;
  {
  fprintf(_coverage_fout, "571\n");
  fflush(_coverage_fout);
  }
  n = (int )dircount;
  {
  fprintf(_coverage_fout, "572\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "280\n");
    fflush(_coverage_fout);
    }
    if (n > 0) {
      {
      fprintf(_coverage_fout, "271\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "281\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "272\n");
      fflush(_coverage_fout);
      }
      TIFFSwabArrayOfShort(& dp->tdir_tag, 2UL);
      {
      fprintf(_coverage_fout, "273\n");
      fflush(_coverage_fout);
      }
      TIFFSwabArrayOfLong(& dp->tdir_count, 2UL);
    } else {
      {
      fprintf(_coverage_fout, "274\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "282\n");
    fflush(_coverage_fout);
    }
    if ((int )dp->tdir_tag == 277) {
      {
      fprintf(_coverage_fout, "276\n");
      fflush(_coverage_fout);
      }
      tmp___6 = TIFFFetchNormalTag(tif, dp);
      {
      fprintf(_coverage_fout, "277\n");
      fflush(_coverage_fout);
      }
      if (tmp___6) {
        {
        fprintf(_coverage_fout, "275\n");
        fflush(_coverage_fout);
        }

      } else {
        goto bad;
      }
      {
      fprintf(_coverage_fout, "278\n");
      fflush(_coverage_fout);
      }
      dp->tdir_tag = (unsigned short)0;
    } else {
      {
      fprintf(_coverage_fout, "279\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "283\n");
    fflush(_coverage_fout);
    }
    n --;
    {
    fprintf(_coverage_fout, "284\n");
    fflush(_coverage_fout);
    }
    dp ++;
  }
  {
  fprintf(_coverage_fout, "573\n");
  fflush(_coverage_fout);
  }
  fix = 0U;
  {
  fprintf(_coverage_fout, "574\n");
  fflush(_coverage_fout);
  }
  dp = dir;
  {
  fprintf(_coverage_fout, "575\n");
  fflush(_coverage_fout);
  }
  n = (int )dircount;
  {
  fprintf(_coverage_fout, "576\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    }
    if (n > 0) {
      {
      fprintf(_coverage_fout, "285\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "359\n");
    fflush(_coverage_fout);
    }
    if (fix >= tif->tif_nfields) {
      goto __Cont;
    } else {
      {
      fprintf(_coverage_fout, "287\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_tag == 0) {
        goto __Cont;
      } else {
        {
        fprintf(_coverage_fout, "286\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "360\n");
    fflush(_coverage_fout);
    }
    if ((ttag_t )dp->tdir_tag < (*(tif->tif_fieldinfo + fix))->field_tag) {
      {
      fprintf(_coverage_fout, "291\n");
      fflush(_coverage_fout);
      }
      if (! diroutoforderwarning) {
        {
        fprintf(_coverage_fout, "288\n");
        fflush(_coverage_fout);
        }
        TIFFWarningExt(tif->tif_clientdata, module,
                       "%s: invalid TIFF directory; tags are not sorted in ascending order",
                       tif->tif_name);
        {
        fprintf(_coverage_fout, "289\n");
        fflush(_coverage_fout);
        }
        diroutoforderwarning = 1;
      } else {
        {
        fprintf(_coverage_fout, "290\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "292\n");
      fflush(_coverage_fout);
      }
      fix = 0U;
    } else {
      {
      fprintf(_coverage_fout, "293\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "361\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "296\n");
      fflush(_coverage_fout);
      }
      if (fix < tif->tif_nfields) {
        {
        fprintf(_coverage_fout, "295\n");
        fflush(_coverage_fout);
        }
        if ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag) {
          {
          fprintf(_coverage_fout, "294\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "297\n");
      fflush(_coverage_fout);
      }
      fix ++;
    }
    {
    fprintf(_coverage_fout, "362\n");
    fflush(_coverage_fout);
    }
    if (fix >= tif->tif_nfields) {
      goto _L;
    } else {
      {
      fprintf(_coverage_fout, "308\n");
      fflush(_coverage_fout);
      }
      if ((*(tif->tif_fieldinfo + fix))->field_tag != (ttag_t )dp->tdir_tag) {
        {
        fprintf(_coverage_fout, "302\n");
        fflush(_coverage_fout);
        }
        _L: /* CIL Label */ 
        TIFFWarningExt(tif->tif_clientdata, module,
                       "%s: unknown field with tag %d (0x%x) encountered",
                       tif->tif_name, dp->tdir_tag, dp->tdir_tag, dp->tdir_type);
        {
        fprintf(_coverage_fout, "303\n");
        fflush(_coverage_fout);
        }
        tmp___7 = _TIFFCreateAnonFieldInfo(tif, (unsigned int )dp->tdir_tag,
                                           (enum __anonenum_TIFFDataType_20 )dp->tdir_type);
        {
        fprintf(_coverage_fout, "304\n");
        fflush(_coverage_fout);
        }
        TIFFMergeFieldInfo(tif, (TIFFFieldInfo const   *)tmp___7, 1);
        {
        fprintf(_coverage_fout, "305\n");
        fflush(_coverage_fout);
        }
        fix = 0U;
        {
        fprintf(_coverage_fout, "306\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "300\n");
          fflush(_coverage_fout);
          }
          if (fix < tif->tif_nfields) {
            {
            fprintf(_coverage_fout, "299\n");
            fflush(_coverage_fout);
            }
            if ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag) {
              {
              fprintf(_coverage_fout, "298\n");
              fflush(_coverage_fout);
              }

            } else {
              break;
            }
          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "301\n");
          fflush(_coverage_fout);
          }
          fix ++;
        }
      } else {
        {
        fprintf(_coverage_fout, "307\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "363\n");
    fflush(_coverage_fout);
    }
    if ((int )(*(tif->tif_fieldinfo + fix))->field_bit == 0) {
      {
      fprintf(_coverage_fout, "309\n");
      fflush(_coverage_fout);
      }
      ignore: 
      dp->tdir_tag = (unsigned short)0;
      goto __Cont;
    } else {
      {
      fprintf(_coverage_fout, "310\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "364\n");
    fflush(_coverage_fout);
    }
    fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
    {
    fprintf(_coverage_fout, "365\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "318\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_type != (int )((unsigned short )fip->field_type)) {
        {
        fprintf(_coverage_fout, "312\n");
        fflush(_coverage_fout);
        }
        if (fix < tif->tif_nfields) {
          {
          fprintf(_coverage_fout, "311\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "319\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int const   )fip->field_type == 0U) {
        break;
      } else {
        {
        fprintf(_coverage_fout, "313\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "320\n");
      fflush(_coverage_fout);
      }
      fix ++;
      {
      fprintf(_coverage_fout, "321\n");
      fflush(_coverage_fout);
      }
      fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
      {
      fprintf(_coverage_fout, "322\n");
      fflush(_coverage_fout);
      }
      if (fix >= tif->tif_nfields) {
        {
        fprintf(_coverage_fout, "314\n");
        fflush(_coverage_fout);
        }
        TIFFWarningExt(tif->tif_clientdata, module,
                       "%s: wrong data type %d for \"%s\"; tag ignored",
                       tif->tif_name, dp->tdir_type,
                       (*(tif->tif_fieldinfo + (fix - 1U)))->field_name);
        goto ignore;
      } else {
        {
        fprintf(_coverage_fout, "317\n");
        fflush(_coverage_fout);
        }
        if (fip->field_tag != (ttag_t const   )dp->tdir_tag) {
          {
          fprintf(_coverage_fout, "315\n");
          fflush(_coverage_fout);
          }
          TIFFWarningExt(tif->tif_clientdata, module,
                         "%s: wrong data type %d for \"%s\"; tag ignored",
                         tif->tif_name, dp->tdir_type,
                         (*(tif->tif_fieldinfo + (fix - 1U)))->field_name);
          goto ignore;
        } else {
          {
          fprintf(_coverage_fout, "316\n");
          fflush(_coverage_fout);
          }

        }
      }
    }
    {
    fprintf(_coverage_fout, "366\n");
    fflush(_coverage_fout);
    }
    if ((int const   )fip->field_readcount != -1) {
      {
      fprintf(_coverage_fout, "331\n");
      fflush(_coverage_fout);
      }
      if ((int const   )fip->field_readcount != -3) {
        {
        fprintf(_coverage_fout, "326\n");
        fflush(_coverage_fout);
        }
        if ((int const   )fip->field_readcount == -2) {
          {
          fprintf(_coverage_fout, "323\n");
          fflush(_coverage_fout);
          }
          tmp___8 = (unsigned int )td->td_samplesperpixel;
        } else {
          {
          fprintf(_coverage_fout, "324\n");
          fflush(_coverage_fout);
          }
          tmp___8 = (unsigned int )fip->field_readcount;
        }
        {
        fprintf(_coverage_fout, "327\n");
        fflush(_coverage_fout);
        }
        expected = tmp___8;
        {
        fprintf(_coverage_fout, "328\n");
        fflush(_coverage_fout);
        }
        tmp___9 = CheckDirCount(tif, dp, expected);
        {
        fprintf(_coverage_fout, "329\n");
        fflush(_coverage_fout);
        }
        if (tmp___9) {
          {
          fprintf(_coverage_fout, "325\n");
          fflush(_coverage_fout);
          }

        } else {
          goto ignore;
        }
      } else {
        {
        fprintf(_coverage_fout, "330\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "332\n");
      fflush(_coverage_fout);
      }

    }
    switch ((int )dp->tdir_tag) {
    {
    fprintf(_coverage_fout, "352\n");
    fflush(_coverage_fout);
    }
    case 259: 
    if (dp->tdir_count == 1U) {
      {
      fprintf(_coverage_fout, "336\n");
      fflush(_coverage_fout);
      }
      if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
        {
        fprintf(_coverage_fout, "333\n");
        fflush(_coverage_fout);
        }
        tmp___10 = (unsigned long )(dp->tdir_offset >> *(tif->tif_typeshift + dp->tdir_type)) & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      } else {
        {
        fprintf(_coverage_fout, "334\n");
        fflush(_coverage_fout);
        }
        tmp___10 = (unsigned long )dp->tdir_offset & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      }
      {
      fprintf(_coverage_fout, "337\n");
      fflush(_coverage_fout);
      }
      v = (unsigned int )tmp___10;
      {
      fprintf(_coverage_fout, "338\n");
      fflush(_coverage_fout);
      }
      tmp___11 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                              (unsigned short )v);
      {
      fprintf(_coverage_fout, "339\n");
      fflush(_coverage_fout);
      }
      if (tmp___11) {
        {
        fprintf(_coverage_fout, "335\n");
        fflush(_coverage_fout);
        }

      } else {
        goto bad;
      }
      break;
    } else {
      {
      fprintf(_coverage_fout, "350\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_type == 4) {
        {
        fprintf(_coverage_fout, "343\n");
        fflush(_coverage_fout);
        }
        tmp___12 = TIFFFetchPerSampleLongs(tif, dp, & v);
        {
        fprintf(_coverage_fout, "344\n");
        fflush(_coverage_fout);
        }
        if (tmp___12) {
          {
          fprintf(_coverage_fout, "341\n");
          fflush(_coverage_fout);
          }
          tmp___13 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                                  (unsigned short )v);
          {
          fprintf(_coverage_fout, "342\n");
          fflush(_coverage_fout);
          }
          if (tmp___13) {
            {
            fprintf(_coverage_fout, "340\n");
            fflush(_coverage_fout);
            }

          } else {
            goto bad;
          }
        } else {
          goto bad;
        }
      } else {
        {
        fprintf(_coverage_fout, "348\n");
        fflush(_coverage_fout);
        }
        tmp___14 = TIFFFetchPerSampleShorts(tif, dp, & iv);
        {
        fprintf(_coverage_fout, "349\n");
        fflush(_coverage_fout);
        }
        if (tmp___14) {
          {
          fprintf(_coverage_fout, "346\n");
          fflush(_coverage_fout);
          }
          tmp___15 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, iv);
          {
          fprintf(_coverage_fout, "347\n");
          fflush(_coverage_fout);
          }
          if (tmp___15) {
            {
            fprintf(_coverage_fout, "345\n");
            fflush(_coverage_fout);
            }

          } else {
            goto bad;
          }
        } else {
          goto bad;
        }
      }
    }
    {
    fprintf(_coverage_fout, "353\n");
    fflush(_coverage_fout);
    }
    dp->tdir_tag = (unsigned short)0;
    break;
    {
    fprintf(_coverage_fout, "354\n");
    fflush(_coverage_fout);
    }
    case 273: 
    case 279: 
    case 324: 
    case 325: 
    tif->tif_dir.td_fieldsset[(int const   )fip->field_bit / 32] |= 1UL << ((int const   )fip->field_bit & 31);
    break;
    {
    fprintf(_coverage_fout, "355\n");
    fflush(_coverage_fout);
    }
    case 256: 
    case 257: 
    case 32997: 
    case 323: 
    case 322: 
    case 32998: 
    case 284: 
    case 278: 
    case 338: 
    tmp___16 = TIFFFetchNormalTag(tif, dp);
    {
    fprintf(_coverage_fout, "356\n");
    fflush(_coverage_fout);
    }
    if (tmp___16) {
      {
      fprintf(_coverage_fout, "351\n");
      fflush(_coverage_fout);
      }

    } else {
      goto bad;
    }
    {
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    }
    dp->tdir_tag = (unsigned short)0;
    break;
    }
    {
    fprintf(_coverage_fout, "367\n");
    fflush(_coverage_fout);
    }
    __Cont: /* CIL Label */ 
    n --;
    {
    fprintf(_coverage_fout, "368\n");
    fflush(_coverage_fout);
    }
    dp ++;
  }
  {
  fprintf(_coverage_fout, "577\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 1))) {
    {
    fprintf(_coverage_fout, "369\n");
    fflush(_coverage_fout);
    }
    MissingRequired(tif, "ImageLength");
    goto bad;
  } else {
    {
    fprintf(_coverage_fout, "370\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "578\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 20))) {
    {
    fprintf(_coverage_fout, "371\n");
    fflush(_coverage_fout);
    }
    MissingRequired(tif, "PlanarConfiguration");
    goto bad;
  } else {
    {
    fprintf(_coverage_fout, "372\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "579\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 2))) {
    {
    fprintf(_coverage_fout, "373\n");
    fflush(_coverage_fout);
    }
    td->td_nstrips = TIFFNumberOfStrips(tif);
    {
    fprintf(_coverage_fout, "374\n");
    fflush(_coverage_fout);
    }
    td->td_tilewidth = td->td_imagewidth;
    {
    fprintf(_coverage_fout, "375\n");
    fflush(_coverage_fout);
    }
    td->td_tilelength = td->td_rowsperstrip;
    {
    fprintf(_coverage_fout, "376\n");
    fflush(_coverage_fout);
    }
    td->td_tiledepth = td->td_imagedepth;
    {
    fprintf(_coverage_fout, "377\n");
    fflush(_coverage_fout);
    }
    tif->tif_flags &= 4294966271U;
  } else {
    {
    fprintf(_coverage_fout, "378\n");
    fflush(_coverage_fout);
    }
    td->td_nstrips = TIFFNumberOfTiles(tif);
    {
    fprintf(_coverage_fout, "379\n");
    fflush(_coverage_fout);
    }
    tif->tif_flags |= 1024U;
  }
  {
  fprintf(_coverage_fout, "580\n");
  fflush(_coverage_fout);
  }
  if (! td->td_nstrips) {
    {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    }
    if ((tif->tif_flags & 1024U) != 0U) {
      {
      fprintf(_coverage_fout, "380\n");
      fflush(_coverage_fout);
      }
      tmp___17 = "tiles";
    } else {
      {
      fprintf(_coverage_fout, "381\n");
      fflush(_coverage_fout);
      }
      tmp___17 = "strips";
    }
    {
    fprintf(_coverage_fout, "383\n");
    fflush(_coverage_fout);
    }
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: cannot handle zero number of %s", tif->tif_name, tmp___17);
    goto bad;
  } else {
    {
    fprintf(_coverage_fout, "384\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "581\n");
  fflush(_coverage_fout);
  }
  td->td_stripsperimage = td->td_nstrips;
  {
  fprintf(_coverage_fout, "582\n");
  fflush(_coverage_fout);
  }
  if ((int )td->td_planarconfig == 2) {
    {
    fprintf(_coverage_fout, "385\n");
    fflush(_coverage_fout);
    }
    td->td_stripsperimage /= (tstrip_t )td->td_samplesperpixel;
  } else {
    {
    fprintf(_coverage_fout, "386\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "583\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 25))) {
    {
    fprintf(_coverage_fout, "389\n");
    fflush(_coverage_fout);
    }
    if ((tif->tif_flags & 1024U) != 0U) {
      {
      fprintf(_coverage_fout, "387\n");
      fflush(_coverage_fout);
      }
      tmp___18 = "TileOffsets";
    } else {
      {
      fprintf(_coverage_fout, "388\n");
      fflush(_coverage_fout);
      }
      tmp___18 = "StripOffsets";
    }
    {
    fprintf(_coverage_fout, "390\n");
    fflush(_coverage_fout);
    }
    MissingRequired(tif, tmp___18);
    goto bad;
  } else {
    {
    fprintf(_coverage_fout, "391\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "584\n");
  fflush(_coverage_fout);
  }
  dp = dir;
  {
  fprintf(_coverage_fout, "585\n");
  fflush(_coverage_fout);
  }
  n = (int )dircount;
  {
  fprintf(_coverage_fout, "586\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "459\n");
    fflush(_coverage_fout);
    }
    if (n > 0) {
      {
      fprintf(_coverage_fout, "392\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "460\n");
    fflush(_coverage_fout);
    }
    if ((int )dp->tdir_tag == 0) {
      goto __Cont___0;
    } else {
      {
      fprintf(_coverage_fout, "393\n");
      fflush(_coverage_fout);
      }

    }
    switch ((int )dp->tdir_tag) {
    {
    fprintf(_coverage_fout, "439\n");
    fflush(_coverage_fout);
    }
    case 280: 
    case 281: 
    case 258: 
    case 32996: 
    case 339: 
    if (dp->tdir_count == 1U) {
      {
      fprintf(_coverage_fout, "397\n");
      fflush(_coverage_fout);
      }
      if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
        {
        fprintf(_coverage_fout, "394\n");
        fflush(_coverage_fout);
        }
        tmp___19 = (unsigned long )(dp->tdir_offset >> *(tif->tif_typeshift + dp->tdir_type)) & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      } else {
        {
        fprintf(_coverage_fout, "395\n");
        fflush(_coverage_fout);
        }
        tmp___19 = (unsigned long )dp->tdir_offset & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      }
      {
      fprintf(_coverage_fout, "398\n");
      fflush(_coverage_fout);
      }
      v = (unsigned int )tmp___19;
      {
      fprintf(_coverage_fout, "399\n");
      fflush(_coverage_fout);
      }
      tmp___20 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                              (unsigned short )v);
      {
      fprintf(_coverage_fout, "400\n");
      fflush(_coverage_fout);
      }
      if (tmp___20) {
        {
        fprintf(_coverage_fout, "396\n");
        fflush(_coverage_fout);
        }

      } else {
        goto bad;
      }
    } else {
      {
      fprintf(_coverage_fout, "412\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_tag == 258) {
        {
        fprintf(_coverage_fout, "406\n");
        fflush(_coverage_fout);
        }
        if ((int )dp->tdir_type == 4) {
          {
          fprintf(_coverage_fout, "404\n");
          fflush(_coverage_fout);
          }
          tmp___21 = TIFFFetchPerSampleLongs(tif, dp, & v);
          {
          fprintf(_coverage_fout, "405\n");
          fflush(_coverage_fout);
          }
          if (tmp___21) {
            {
            fprintf(_coverage_fout, "402\n");
            fflush(_coverage_fout);
            }
            tmp___22 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                                    (unsigned short )v);
            {
            fprintf(_coverage_fout, "403\n");
            fflush(_coverage_fout);
            }
            if (tmp___22) {
              {
              fprintf(_coverage_fout, "401\n");
              fflush(_coverage_fout);
              }

            } else {
              goto bad;
            }
          } else {
            goto bad;
          }
        } else {
          goto _L___0;
        }
      } else {
        {
        fprintf(_coverage_fout, "410\n");
        fflush(_coverage_fout);
        }
        _L___0: /* CIL Label */ 
        tmp___23 = TIFFFetchPerSampleShorts(tif, dp, & iv);
        {
        fprintf(_coverage_fout, "411\n");
        fflush(_coverage_fout);
        }
        if (tmp___23) {
          {
          fprintf(_coverage_fout, "408\n");
          fflush(_coverage_fout);
          }
          tmp___24 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, iv);
          {
          fprintf(_coverage_fout, "409\n");
          fflush(_coverage_fout);
          }
          if (tmp___24) {
            {
            fprintf(_coverage_fout, "407\n");
            fflush(_coverage_fout);
            }

          } else {
            goto bad;
          }
        } else {
          goto bad;
        }
      }
    }
    break;
    {
    fprintf(_coverage_fout, "440\n");
    fflush(_coverage_fout);
    }
    case 340: 
    case 341: 
    dv = 0.0;
    {
    fprintf(_coverage_fout, "441\n");
    fflush(_coverage_fout);
    }
    tmp___25 = TIFFFetchPerSampleAnys(tif, dp, & dv);
    {
    fprintf(_coverage_fout, "442\n");
    fflush(_coverage_fout);
    }
    if (tmp___25) {
      {
      fprintf(_coverage_fout, "414\n");
      fflush(_coverage_fout);
      }
      tmp___26 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, dv);
      {
      fprintf(_coverage_fout, "415\n");
      fflush(_coverage_fout);
      }
      if (tmp___26) {
        {
        fprintf(_coverage_fout, "413\n");
        fflush(_coverage_fout);
        }

      } else {
        goto bad;
      }
    } else {
      goto bad;
    }
    break;
    {
    fprintf(_coverage_fout, "443\n");
    fflush(_coverage_fout);
    }
    case 273: 
    case 324: 
    tmp___27 = TIFFFetchStripThing(tif, dp, (long )td->td_nstrips,
                                   & td->td_stripoffset);
    {
    fprintf(_coverage_fout, "444\n");
    fflush(_coverage_fout);
    }
    if (tmp___27) {
      {
      fprintf(_coverage_fout, "416\n");
      fflush(_coverage_fout);
      }

    } else {
      goto bad;
    }
    break;
    {
    fprintf(_coverage_fout, "445\n");
    fflush(_coverage_fout);
    }
    case 279: 
    case 325: 
    tmp___28 = TIFFFetchStripThing(tif, dp, (long )td->td_nstrips,
                                   & td->td_stripbytecount);
    {
    fprintf(_coverage_fout, "446\n");
    fflush(_coverage_fout);
    }
    if (tmp___28) {
      {
      fprintf(_coverage_fout, "417\n");
      fflush(_coverage_fout);
      }

    } else {
      goto bad;
    }
    break;
    {
    fprintf(_coverage_fout, "447\n");
    fflush(_coverage_fout);
    }
    case 320: 
    case 301: 
    v = (unsigned int )(1L << (int )td->td_bitspersample);
    {
    fprintf(_coverage_fout, "448\n");
    fflush(_coverage_fout);
    }
    if ((int )dp->tdir_tag == 320) {
      goto _L___1;
    } else {
      {
      fprintf(_coverage_fout, "422\n");
      fflush(_coverage_fout);
      }
      if (dp->tdir_count != v) {
        {
        fprintf(_coverage_fout, "419\n");
        fflush(_coverage_fout);
        }
        _L___1: /* CIL Label */ 
        tmp___29 = CheckDirCount(tif, dp, 3U * v);
        {
        fprintf(_coverage_fout, "420\n");
        fflush(_coverage_fout);
        }
        if (tmp___29) {
          {
          fprintf(_coverage_fout, "418\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        {
        fprintf(_coverage_fout, "421\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "449\n");
    fflush(_coverage_fout);
    }
    v *= sizeof(uint16 );
    {
    fprintf(_coverage_fout, "450\n");
    fflush(_coverage_fout);
    }
    tmp___30 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(uint16 ),
                                "to read \"TransferFunction\" tag");
    {
    fprintf(_coverage_fout, "451\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___30;
    {
    fprintf(_coverage_fout, "452\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )cp != (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "429\n");
      fflush(_coverage_fout);
      }
      tmp___31 = TIFFFetchData(tif, dp, cp);
      {
      fprintf(_coverage_fout, "430\n");
      fflush(_coverage_fout);
      }
      if (tmp___31) {
        {
        fprintf(_coverage_fout, "425\n");
        fflush(_coverage_fout);
        }
        c = (uint32 )(1L << (int )td->td_bitspersample);
        {
        fprintf(_coverage_fout, "426\n");
        fflush(_coverage_fout);
        }
        if (dp->tdir_count == c) {
          {
          fprintf(_coverage_fout, "423\n");
          fflush(_coverage_fout);
          }
          v = 0U;
        } else {
          {
          fprintf(_coverage_fout, "424\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "427\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(tif, (unsigned int )dp->tdir_tag, cp, cp + v, cp + 2U * v);
      } else {
        {
        fprintf(_coverage_fout, "428\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "431\n");
      fflush(_coverage_fout);
      }
      _TIFFfree((void *)cp);
    } else {
      {
      fprintf(_coverage_fout, "432\n");
      fflush(_coverage_fout);
      }

    }
    break;
    {
    fprintf(_coverage_fout, "453\n");
    fflush(_coverage_fout);
    }
    case 297: 
    case 321: 
    case 530: 
    case 336: 
    TIFFFetchShortPair(tif, dp);
    break;
    {
    fprintf(_coverage_fout, "454\n");
    fflush(_coverage_fout);
    }
    case 532: 
    TIFFFetchRefBlackWhite(tif, dp);
    break;
    {
    fprintf(_coverage_fout, "455\n");
    fflush(_coverage_fout);
    }
    case 255: 
    v = 0U;
    {
    fprintf(_coverage_fout, "456\n");
    fflush(_coverage_fout);
    }
    if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
      {
      fprintf(_coverage_fout, "433\n");
      fflush(_coverage_fout);
      }
      tmp___32 = (unsigned long )(dp->tdir_offset >> *(tif->tif_typeshift + dp->tdir_type)) & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
    } else {
      {
      fprintf(_coverage_fout, "434\n");
      fflush(_coverage_fout);
      }
      tmp___32 = (unsigned long )dp->tdir_offset & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
    }
    switch ((int )((unsigned int )tmp___32)) {
    {
    fprintf(_coverage_fout, "435\n");
    fflush(_coverage_fout);
    }
    case 2: 
    v = 1U;
    break;
    {
    fprintf(_coverage_fout, "436\n");
    fflush(_coverage_fout);
    }
    case 3: 
    v = 2U;
    break;
    }
    {
    fprintf(_coverage_fout, "457\n");
    fflush(_coverage_fout);
    }
    if (v) {
      {
      fprintf(_coverage_fout, "437\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(tif, 254U, v);
    } else {
      {
      fprintf(_coverage_fout, "438\n");
      fflush(_coverage_fout);
      }

    }
    break;
    {
    fprintf(_coverage_fout, "458\n");
    fflush(_coverage_fout);
    }
    default: 
    TIFFFetchNormalTag(tif, dp);
    break;
    }
    {
    fprintf(_coverage_fout, "461\n");
    fflush(_coverage_fout);
    }
    __Cont___0: /* CIL Label */ 
    n --;
    {
    fprintf(_coverage_fout, "462\n");
    fflush(_coverage_fout);
    }
    dp ++;
  }
  {
  fprintf(_coverage_fout, "587\n");
  fflush(_coverage_fout);
  }
  if ((int )td->td_photometric == 3) {
    {
    fprintf(_coverage_fout, "465\n");
    fflush(_coverage_fout);
    }
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 26))) {
      {
      fprintf(_coverage_fout, "463\n");
      fflush(_coverage_fout);
      }
      MissingRequired(tif, "Colormap");
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "464\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "466\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "588\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 24))) {
    {
    fprintf(_coverage_fout, "475\n");
    fflush(_coverage_fout);
    }
    if ((int )td->td_planarconfig == 1) {
      {
      fprintf(_coverage_fout, "468\n");
      fflush(_coverage_fout);
      }
      if (td->td_nstrips > 1U) {
        {
        fprintf(_coverage_fout, "467\n");
        fflush(_coverage_fout);
        }
        MissingRequired(tif, "StripByteCounts");
        goto bad;
      } else {
        goto _L___2;
      }
    } else {
      {
      fprintf(_coverage_fout, "473\n");
      fflush(_coverage_fout);
      }
      _L___2: /* CIL Label */ 
      if ((int )td->td_planarconfig == 2) {
        {
        fprintf(_coverage_fout, "471\n");
        fflush(_coverage_fout);
        }
        if (td->td_nstrips != (tstrip_t )td->td_samplesperpixel) {
          {
          fprintf(_coverage_fout, "469\n");
          fflush(_coverage_fout);
          }
          MissingRequired(tif, "StripByteCounts");
          goto bad;
        } else {
          {
          fprintf(_coverage_fout, "470\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "472\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "476\n");
    fflush(_coverage_fout);
    }
    tmp___33 = TIFFFieldWithTag(tif, 279U);
    {
    fprintf(_coverage_fout, "477\n");
    fflush(_coverage_fout);
    }
    TIFFWarningExt(tif->tif_clientdata, module,
                   "%s: TIFF directory is missing required \"%s\" field, calculating from imagelength",
                   tif->tif_name, tmp___33->field_name);
    {
    fprintf(_coverage_fout, "478\n");
    fflush(_coverage_fout);
    }
    tmp___34 = EstimateStripByteCounts(tif, dir, dircount);
    {
    fprintf(_coverage_fout, "479\n");
    fflush(_coverage_fout);
    }
    if (tmp___34 < 0) {
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "474\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "508\n");
    fflush(_coverage_fout);
    }
    if (td->td_nstrips == 1U) {
      {
      fprintf(_coverage_fout, "494\n");
      fflush(_coverage_fout);
      }
      if (*(td->td_stripoffset + 0) != 0U) {
        {
        fprintf(_coverage_fout, "493\n");
        fflush(_coverage_fout);
        }
        if (*(td->td_stripbytecount + 0) == 0U) {
          {
          fprintf(_coverage_fout, "480\n");
          fflush(_coverage_fout);
          }
          if (*(td->td_stripoffset + 0) != 0U) {
            goto _L___4;
          } else {
            goto _L___6;
          }
        } else {
          {
          fprintf(_coverage_fout, "492\n");
          fflush(_coverage_fout);
          }
          _L___6: /* CIL Label */ 
          if ((int )td->td_compression == 1) {
            {
            fprintf(_coverage_fout, "481\n");
            fflush(_coverage_fout);
            }
            tmp___39 = (*(tif->tif_sizeproc))(tif->tif_clientdata);
            {
            fprintf(_coverage_fout, "482\n");
            fflush(_coverage_fout);
            }
            if (*(td->td_stripbytecount + 0) > tmp___39 - *(td->td_stripoffset + 0)) {
              goto _L___4;
            } else {
              goto _L___5;
            }
          } else {
            {
            fprintf(_coverage_fout, "491\n");
            fflush(_coverage_fout);
            }
            _L___5: /* CIL Label */ 
            if (tif->tif_mode == 00) {
              {
              fprintf(_coverage_fout, "490\n");
              fflush(_coverage_fout);
              }
              if ((int )td->td_compression == 1) {
                {
                fprintf(_coverage_fout, "488\n");
                fflush(_coverage_fout);
                }
                tmp___40 = TIFFScanlineSize(tif);
                {
                fprintf(_coverage_fout, "489\n");
                fflush(_coverage_fout);
                }
                if (*(td->td_stripbytecount + 0) < (uint32 )tmp___40 * td->td_imagelength) {
                  {
                  fprintf(_coverage_fout, "484\n");
                  fflush(_coverage_fout);
                  }
                  _L___4: /* CIL Label */ 
                  tmp___35 = TIFFFieldWithTag(tif, 279U);
                  {
                  fprintf(_coverage_fout, "485\n");
                  fflush(_coverage_fout);
                  }
                  TIFFWarningExt(tif->tif_clientdata, module,
                                 "%s: Bogus \"%s\" field, ignoring and calculating from imagelength",
                                 tif->tif_name, tmp___35->field_name);
                  {
                  fprintf(_coverage_fout, "486\n");
                  fflush(_coverage_fout);
                  }
                  tmp___36 = EstimateStripByteCounts(tif, dir, dircount);
                  {
                  fprintf(_coverage_fout, "487\n");
                  fflush(_coverage_fout);
                  }
                  if (tmp___36 < 0) {
                    goto bad;
                  } else {
                    {
                    fprintf(_coverage_fout, "483\n");
                    fflush(_coverage_fout);
                    }

                  }
                } else {
                  goto _L___7;
                }
              } else {
                goto _L___7;
              }
            } else {
              goto _L___7;
            }
          }
        }
      } else {
        goto _L___7;
      }
    } else {
      {
      fprintf(_coverage_fout, "507\n");
      fflush(_coverage_fout);
      }
      _L___7: /* CIL Label */ 
      _L___3: /* CIL Label */ 
      if ((int )td->td_planarconfig == 1) {
        {
        fprintf(_coverage_fout, "505\n");
        fflush(_coverage_fout);
        }
        if (td->td_nstrips > 2U) {
          {
          fprintf(_coverage_fout, "503\n");
          fflush(_coverage_fout);
          }
          if ((int )td->td_compression == 1) {
            {
            fprintf(_coverage_fout, "501\n");
            fflush(_coverage_fout);
            }
            if (*(td->td_stripbytecount + 0) != *(td->td_stripbytecount + 1)) {
              {
              fprintf(_coverage_fout, "496\n");
              fflush(_coverage_fout);
              }
              tmp___37 = TIFFFieldWithTag(tif, 279U);
              {
              fprintf(_coverage_fout, "497\n");
              fflush(_coverage_fout);
              }
              TIFFWarningExt(tif->tif_clientdata, module,
                             "%s: Wrong \"%s\" field, ignoring and calculating from imagelength",
                             tif->tif_name, tmp___37->field_name);
              {
              fprintf(_coverage_fout, "498\n");
              fflush(_coverage_fout);
              }
              tmp___38 = EstimateStripByteCounts(tif, dir, dircount);
              {
              fprintf(_coverage_fout, "499\n");
              fflush(_coverage_fout);
              }
              if (tmp___38 < 0) {
                goto bad;
              } else {
                {
                fprintf(_coverage_fout, "495\n");
                fflush(_coverage_fout);
                }

              }
            } else {
              {
              fprintf(_coverage_fout, "500\n");
              fflush(_coverage_fout);
              }

            }
          } else {
            {
            fprintf(_coverage_fout, "502\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "504\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "506\n");
        fflush(_coverage_fout);
        }

      }
    }
  }
  {
  fprintf(_coverage_fout, "589\n");
  fflush(_coverage_fout);
  }
  if (dir) {
    {
    fprintf(_coverage_fout, "509\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)((char *)dir));
    {
    fprintf(_coverage_fout, "510\n");
    fflush(_coverage_fout);
    }
    dir = (TIFFDirEntry *)((void *)0);
  } else {
    {
    fprintf(_coverage_fout, "511\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "590\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 19))) {
    {
    fprintf(_coverage_fout, "512\n");
    fflush(_coverage_fout);
    }
    td->td_maxsamplevalue = (unsigned short )((1L << (int )td->td_bitspersample) - 1L);
  } else {
    {
    fprintf(_coverage_fout, "513\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "591\n");
  fflush(_coverage_fout);
  }
  if (td->td_nstrips > 1U) {
    {
    fprintf(_coverage_fout, "520\n");
    fflush(_coverage_fout);
    }
    td->td_stripbytecountsorted = 1;
    {
    fprintf(_coverage_fout, "521\n");
    fflush(_coverage_fout);
    }
    strip = 1U;
    {
    fprintf(_coverage_fout, "522\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "517\n");
      fflush(_coverage_fout);
      }
      if (strip < td->td_nstrips) {
        {
        fprintf(_coverage_fout, "514\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "518\n");
      fflush(_coverage_fout);
      }
      if (*(td->td_stripoffset + (strip - 1U)) > *(td->td_stripoffset + strip)) {
        {
        fprintf(_coverage_fout, "515\n");
        fflush(_coverage_fout);
        }
        td->td_stripbytecountsorted = 0;
        break;
      } else {
        {
        fprintf(_coverage_fout, "516\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "519\n");
      fflush(_coverage_fout);
      }
      strip ++;
    }
  } else {
    {
    fprintf(_coverage_fout, "523\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "592\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 7))) {
    {
    fprintf(_coverage_fout, "524\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(tif, 259U, 1);
  } else {
    {
    fprintf(_coverage_fout, "525\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "593\n");
  fflush(_coverage_fout);
  }
  if (td->td_nstrips == 1U) {
    {
    fprintf(_coverage_fout, "530\n");
    fflush(_coverage_fout);
    }
    if ((int )td->td_compression == 1) {
      {
      fprintf(_coverage_fout, "528\n");
      fflush(_coverage_fout);
      }
      if ((tif->tif_flags & 33792U) == 32768U) {
        {
        fprintf(_coverage_fout, "526\n");
        fflush(_coverage_fout);
        }
        ChopUpSingleUncompressedStrip(tif);
      } else {
        {
        fprintf(_coverage_fout, "527\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "529\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "531\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "594\n");
  fflush(_coverage_fout);
  }
  tif->tif_row = 4294967295U;
  {
  fprintf(_coverage_fout, "595\n");
  fflush(_coverage_fout);
  }
  tif->tif_curstrip = 4294967295U;
  {
  fprintf(_coverage_fout, "596\n");
  fflush(_coverage_fout);
  }
  tif->tif_col = 4294967295U;
  {
  fprintf(_coverage_fout, "597\n");
  fflush(_coverage_fout);
  }
  tif->tif_curtile = 4294967295U;
  {
  fprintf(_coverage_fout, "598\n");
  fflush(_coverage_fout);
  }
  tif->tif_tilesize = -1;
  {
  fprintf(_coverage_fout, "599\n");
  fflush(_coverage_fout);
  }
  tif->tif_scanlinesize = TIFFScanlineSize(tif);
  {
  fprintf(_coverage_fout, "600\n");
  fflush(_coverage_fout);
  }
  if (! tif->tif_scanlinesize) {
    {
    fprintf(_coverage_fout, "532\n");
    fflush(_coverage_fout);
    }
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: cannot handle zero scanline size", tif->tif_name);
    {
    fprintf(_coverage_fout, "533\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "534\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "601\n");
  fflush(_coverage_fout);
  }
  if ((tif->tif_flags & 1024U) != 0U) {
    {
    fprintf(_coverage_fout, "538\n");
    fflush(_coverage_fout);
    }
    tif->tif_tilesize = TIFFTileSize(tif);
    {
    fprintf(_coverage_fout, "539\n");
    fflush(_coverage_fout);
    }
    if (! tif->tif_tilesize) {
      {
      fprintf(_coverage_fout, "535\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: cannot handle zero tile size", tif->tif_name);
      {
      fprintf(_coverage_fout, "536\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "537\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "543\n");
    fflush(_coverage_fout);
    }
    tmp___41 = TIFFStripSize(tif);
    {
    fprintf(_coverage_fout, "544\n");
    fflush(_coverage_fout);
    }
    if (tmp___41) {
      {
      fprintf(_coverage_fout, "540\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "541\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: cannot handle zero strip size", tif->tif_name);
      {
      fprintf(_coverage_fout, "542\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
  }
  {
  fprintf(_coverage_fout, "602\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "603\n");
  fflush(_coverage_fout);
  }
  bad: 
  if (dir) {
    {
    fprintf(_coverage_fout, "545\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)dir);
  } else {
    {
    fprintf(_coverage_fout, "546\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "604\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static char const   module___0[24]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'C',      (char const   )'u',      (char const   )'s',      (char const   )'t', 
        (char const   )'o',      (char const   )'m',      (char const   )'D',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'c',      (char const   )'t', 
        (char const   )'o',      (char const   )'r',      (char const   )'y',      (char const   )'\000'};
int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                            TIFFFieldInfo const   *info , size_t n ) 
{ TIFFDirectory *td ;
  TIFFDirEntry *dp ;
  TIFFDirEntry *dir ;
  TIFFFieldInfo const   *fip ;
  size_t fix ;
  uint16 i ;
  uint16 dircount ;
  toff_t tmp ;
  tsize_t tmp___0 ;
  tdata_t tmp___1 ;
  tsize_t tmp___2 ;
  toff_t off ;
  tdata_t tmp___3 ;
  TIFFFieldInfo *tmp___4 ;
  uint32 expected ;
  unsigned int tmp___5 ;
  int tmp___6 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "705\n");
  fflush(_coverage_fout);
  }
  td = & tif->tif_dir;
  {
  fprintf(_coverage_fout, "706\n");
  fflush(_coverage_fout);
  }
  dir = (TIFFDirEntry *)((void *)0);
  {
  fprintf(_coverage_fout, "707\n");
  fflush(_coverage_fout);
  }
  _TIFFSetupFieldInfo(tif, info, n);
  {
  fprintf(_coverage_fout, "708\n");
  fflush(_coverage_fout);
  }
  tif->tif_diroff = diroff;
  {
  fprintf(_coverage_fout, "709\n");
  fflush(_coverage_fout);
  }
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    {
    fprintf(_coverage_fout, "617\n");
    fflush(_coverage_fout);
    }
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, diroff, 0);
    {
    fprintf(_coverage_fout, "618\n");
    fflush(_coverage_fout);
    }
    if (tmp == diroff) {
      {
      fprintf(_coverage_fout, "605\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "606\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Seek error accessing TIFF directory", tif->tif_name);
      {
      fprintf(_coverage_fout, "607\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
    {
    fprintf(_coverage_fout, "619\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)(& dircount),
                                     (int )sizeof(uint16 ));
    {
    fprintf(_coverage_fout, "620\n");
    fflush(_coverage_fout);
    }
    if (tmp___0 == (int )sizeof(uint16 )) {
      {
      fprintf(_coverage_fout, "608\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "609\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      {
      fprintf(_coverage_fout, "610\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
    {
    fprintf(_coverage_fout, "621\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "611\n");
      fflush(_coverage_fout);
      }
      TIFFSwabShort(& dircount);
    } else {
      {
      fprintf(_coverage_fout, "612\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "622\n");
    fflush(_coverage_fout);
    }
    tmp___1 = _TIFFCheckMalloc(tif, (unsigned int )dircount,
                               sizeof(TIFFDirEntry ), "to read TIFF directory");
    {
    fprintf(_coverage_fout, "623\n");
    fflush(_coverage_fout);
    }
    dir = (TIFFDirEntry *)tmp___1;
    {
    fprintf(_coverage_fout, "624\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "613\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "614\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "625\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)dir,
                                     (int )((unsigned int )dircount * sizeof(TIFFDirEntry )));
    {
    fprintf(_coverage_fout, "626\n");
    fflush(_coverage_fout);
    }
    if (tmp___2 == (int )((unsigned int )dircount * sizeof(TIFFDirEntry ))) {
      {
      fprintf(_coverage_fout, "615\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "616\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%.100s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    }
  } else {
    {
    fprintf(_coverage_fout, "636\n");
    fflush(_coverage_fout);
    }
    off = diroff;
    {
    fprintf(_coverage_fout, "637\n");
    fflush(_coverage_fout);
    }
    if (off + sizeof(uint16 ) > tif->tif_size) {
      {
      fprintf(_coverage_fout, "627\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory count", tif->tif_name);
      {
      fprintf(_coverage_fout, "628\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "629\n");
      fflush(_coverage_fout);
      }
      _TIFFmemcpy((void *)(& dircount), (void *)(tif->tif_base + off),
                  (int )sizeof(uint16 ));
    }
    {
    fprintf(_coverage_fout, "638\n");
    fflush(_coverage_fout);
    }
    off += sizeof(uint16 );
    {
    fprintf(_coverage_fout, "639\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "630\n");
      fflush(_coverage_fout);
      }
      TIFFSwabShort(& dircount);
    } else {
      {
      fprintf(_coverage_fout, "631\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "640\n");
    fflush(_coverage_fout);
    }
    tmp___3 = _TIFFCheckMalloc(tif, (unsigned int )dircount,
                               sizeof(TIFFDirEntry ), "to read TIFF directory");
    {
    fprintf(_coverage_fout, "641\n");
    fflush(_coverage_fout);
    }
    dir = (TIFFDirEntry *)tmp___3;
    {
    fprintf(_coverage_fout, "642\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "632\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "633\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "643\n");
    fflush(_coverage_fout);
    }
    if (off + (unsigned int )dircount * sizeof(TIFFDirEntry ) > tif->tif_size) {
      {
      fprintf(_coverage_fout, "634\n");
      fflush(_coverage_fout);
      }
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "%s: Can not read TIFF directory", tif->tif_name);
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "635\n");
      fflush(_coverage_fout);
      }
      _TIFFmemcpy((void *)dir, (void *)(tif->tif_base + off),
                  (int )((unsigned int )dircount * sizeof(TIFFDirEntry )));
    }
  }
  {
  fprintf(_coverage_fout, "710\n");
  fflush(_coverage_fout);
  }
  TIFFFreeDirectory(tif);
  {
  fprintf(_coverage_fout, "711\n");
  fflush(_coverage_fout);
  }
  fix = 0U;
  {
  fprintf(_coverage_fout, "712\n");
  fflush(_coverage_fout);
  }
  dp = dir;
  {
  fprintf(_coverage_fout, "713\n");
  fflush(_coverage_fout);
  }
  i = dircount;
  {
  fprintf(_coverage_fout, "714\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "689\n");
    fflush(_coverage_fout);
    }
    if ((int )i > 0) {
      {
      fprintf(_coverage_fout, "644\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "690\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "645\n");
      fflush(_coverage_fout);
      }
      TIFFSwabArrayOfShort(& dp->tdir_tag, 2UL);
      {
      fprintf(_coverage_fout, "646\n");
      fflush(_coverage_fout);
      }
      TIFFSwabArrayOfLong(& dp->tdir_count, 2UL);
    } else {
      {
      fprintf(_coverage_fout, "647\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "691\n");
    fflush(_coverage_fout);
    }
    if (fix >= tif->tif_nfields) {
      goto __Cont;
    } else {
      {
      fprintf(_coverage_fout, "649\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_tag == 0) {
        goto __Cont;
      } else {
        {
        fprintf(_coverage_fout, "648\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "692\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "652\n");
      fflush(_coverage_fout);
      }
      if (fix < tif->tif_nfields) {
        {
        fprintf(_coverage_fout, "651\n");
        fflush(_coverage_fout);
        }
        if ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag) {
          {
          fprintf(_coverage_fout, "650\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "653\n");
      fflush(_coverage_fout);
      }
      fix ++;
    }
    {
    fprintf(_coverage_fout, "693\n");
    fflush(_coverage_fout);
    }
    if (fix >= tif->tif_nfields) {
      goto _L;
    } else {
      {
      fprintf(_coverage_fout, "664\n");
      fflush(_coverage_fout);
      }
      if ((*(tif->tif_fieldinfo + fix))->field_tag != (ttag_t )dp->tdir_tag) {
        {
        fprintf(_coverage_fout, "658\n");
        fflush(_coverage_fout);
        }
        _L: /* CIL Label */ 
        TIFFWarningExt(tif->tif_clientdata, module___0,
                       "%s: unknown field with tag %d (0x%x) encountered",
                       tif->tif_name, dp->tdir_tag, dp->tdir_tag, dp->tdir_type);
        {
        fprintf(_coverage_fout, "659\n");
        fflush(_coverage_fout);
        }
        tmp___4 = _TIFFCreateAnonFieldInfo(tif, (unsigned int )dp->tdir_tag,
                                           (enum __anonenum_TIFFDataType_20 )dp->tdir_type);
        {
        fprintf(_coverage_fout, "660\n");
        fflush(_coverage_fout);
        }
        TIFFMergeFieldInfo(tif, (TIFFFieldInfo const   *)tmp___4, 1);
        {
        fprintf(_coverage_fout, "661\n");
        fflush(_coverage_fout);
        }
        fix = 0U;
        {
        fprintf(_coverage_fout, "662\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "656\n");
          fflush(_coverage_fout);
          }
          if (fix < tif->tif_nfields) {
            {
            fprintf(_coverage_fout, "655\n");
            fflush(_coverage_fout);
            }
            if ((*(tif->tif_fieldinfo + fix))->field_tag < (ttag_t )dp->tdir_tag) {
              {
              fprintf(_coverage_fout, "654\n");
              fflush(_coverage_fout);
              }

            } else {
              break;
            }
          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "657\n");
          fflush(_coverage_fout);
          }
          fix ++;
        }
      } else {
        {
        fprintf(_coverage_fout, "663\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "694\n");
    fflush(_coverage_fout);
    }
    if ((int )(*(tif->tif_fieldinfo + fix))->field_bit == 0) {
      {
      fprintf(_coverage_fout, "665\n");
      fflush(_coverage_fout);
      }
      ignore: 
      dp->tdir_tag = (unsigned short)0;
      goto __Cont;
    } else {
      {
      fprintf(_coverage_fout, "666\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "695\n");
    fflush(_coverage_fout);
    }
    fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
    {
    fprintf(_coverage_fout, "696\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "674\n");
      fflush(_coverage_fout);
      }
      if ((int )dp->tdir_type != (int )((unsigned short )fip->field_type)) {
        {
        fprintf(_coverage_fout, "668\n");
        fflush(_coverage_fout);
        }
        if (fix < tif->tif_nfields) {
          {
          fprintf(_coverage_fout, "667\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "675\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int const   )fip->field_type == 0U) {
        break;
      } else {
        {
        fprintf(_coverage_fout, "669\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "676\n");
      fflush(_coverage_fout);
      }
      fix ++;
      {
      fprintf(_coverage_fout, "677\n");
      fflush(_coverage_fout);
      }
      fip = (TIFFFieldInfo const   *)*(tif->tif_fieldinfo + fix);
      {
      fprintf(_coverage_fout, "678\n");
      fflush(_coverage_fout);
      }
      if (fix >= tif->tif_nfields) {
        {
        fprintf(_coverage_fout, "670\n");
        fflush(_coverage_fout);
        }
        TIFFWarningExt(tif->tif_clientdata, module___0,
                       "%s: wrong data type %d for \"%s\"; tag ignored",
                       tif->tif_name, dp->tdir_type,
                       (*(tif->tif_fieldinfo + (fix - 1U)))->field_name);
        goto ignore;
      } else {
        {
        fprintf(_coverage_fout, "673\n");
        fflush(_coverage_fout);
        }
        if (fip->field_tag != (ttag_t const   )dp->tdir_tag) {
          {
          fprintf(_coverage_fout, "671\n");
          fflush(_coverage_fout);
          }
          TIFFWarningExt(tif->tif_clientdata, module___0,
                         "%s: wrong data type %d for \"%s\"; tag ignored",
                         tif->tif_name, dp->tdir_type,
                         (*(tif->tif_fieldinfo + (fix - 1U)))->field_name);
          goto ignore;
        } else {
          {
          fprintf(_coverage_fout, "672\n");
          fflush(_coverage_fout);
          }

        }
      }
    }
    {
    fprintf(_coverage_fout, "697\n");
    fflush(_coverage_fout);
    }
    if ((int const   )fip->field_readcount != -1) {
      {
      fprintf(_coverage_fout, "687\n");
      fflush(_coverage_fout);
      }
      if ((int const   )fip->field_readcount != -3) {
        {
        fprintf(_coverage_fout, "682\n");
        fflush(_coverage_fout);
        }
        if ((int const   )fip->field_readcount == -2) {
          {
          fprintf(_coverage_fout, "679\n");
          fflush(_coverage_fout);
          }
          tmp___5 = (unsigned int )td->td_samplesperpixel;
        } else {
          {
          fprintf(_coverage_fout, "680\n");
          fflush(_coverage_fout);
          }
          tmp___5 = (unsigned int )fip->field_readcount;
        }
        {
        fprintf(_coverage_fout, "683\n");
        fflush(_coverage_fout);
        }
        expected = tmp___5;
        {
        fprintf(_coverage_fout, "684\n");
        fflush(_coverage_fout);
        }
        tmp___6 = CheckDirCount(tif, dp, expected);
        {
        fprintf(_coverage_fout, "685\n");
        fflush(_coverage_fout);
        }
        if (tmp___6) {
          {
          fprintf(_coverage_fout, "681\n");
          fflush(_coverage_fout);
          }

        } else {
          goto ignore;
        }
      } else {
        {
        fprintf(_coverage_fout, "686\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "688\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "698\n");
    fflush(_coverage_fout);
    }
    TIFFFetchNormalTag(tif, dp);
    {
    fprintf(_coverage_fout, "699\n");
    fflush(_coverage_fout);
    }
    __Cont: /* CIL Label */ 
    i = (uint16 )((int )i - 1);
    {
    fprintf(_coverage_fout, "700\n");
    fflush(_coverage_fout);
    }
    dp ++;
  }
  {
  fprintf(_coverage_fout, "715\n");
  fflush(_coverage_fout);
  }
  if (dir) {
    {
    fprintf(_coverage_fout, "701\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)dir);
  } else {
    {
    fprintf(_coverage_fout, "702\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "716\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "717\n");
  fflush(_coverage_fout);
  }
  bad: 
  if (dir) {
    {
    fprintf(_coverage_fout, "703\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)dir);
  } else {
    {
    fprintf(_coverage_fout, "704\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "718\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) 
{ size_t exifFieldInfoCount ;
  TIFFFieldInfo const   *exifFieldInfo ;
  TIFFFieldInfo const   *tmp ;
  int tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "719\n");
  fflush(_coverage_fout);
  }
  tmp = _TIFFGetExifFieldInfo(& exifFieldInfoCount);
  {
  fprintf(_coverage_fout, "720\n");
  fflush(_coverage_fout);
  }
  exifFieldInfo = tmp;
  {
  fprintf(_coverage_fout, "721\n");
  fflush(_coverage_fout);
  }
  tmp___0 = TIFFReadCustomDirectory(tif, diroff, exifFieldInfo,
                                    exifFieldInfoCount);
  {
  fprintf(_coverage_fout, "722\n");
  fflush(_coverage_fout);
  }
  return (tmp___0);
}
}
static char const   module___1[24]  = 
  {      (char const   )'E',      (char const   )'s',      (char const   )'t',      (char const   )'i', 
        (char const   )'m',      (char const   )'a',      (char const   )'t',      (char const   )'e', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'C',      (char const   )'o',      (char const   )'u', 
        (char const   )'n',      (char const   )'t',      (char const   )'s',      (char const   )'\000'};
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) 
{ register TIFFDirEntry *dp ;
  register TIFFDirectory *td ;
  uint16 i ;
  tdata_t tmp ;
  uint32 space ;
  toff_t filesize ;
  toff_t tmp___0 ;
  uint16 n ;
  uint32 cc ;
  int tmp___1 ;
  uint32 rowbytes ;
  tsize_t tmp___2 ;
  uint32 rowsperstrip ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "770\n");
  fflush(_coverage_fout);
  }
  td = & tif->tif_dir;
  {
  fprintf(_coverage_fout, "771\n");
  fflush(_coverage_fout);
  }
  if (td->td_stripbytecount) {
    {
    fprintf(_coverage_fout, "723\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)td->td_stripbytecount);
  } else {
    {
    fprintf(_coverage_fout, "724\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "772\n");
  fflush(_coverage_fout);
  }
  tmp = _TIFFCheckMalloc(tif, td->td_nstrips, sizeof(uint32 ),
                         "for \"StripByteCounts\" array");
  {
  fprintf(_coverage_fout, "773\n");
  fflush(_coverage_fout);
  }
  td->td_stripbytecount = (uint32 *)tmp;
  {
  fprintf(_coverage_fout, "774\n");
  fflush(_coverage_fout);
  }
  if ((int )td->td_compression != 1) {
    {
    fprintf(_coverage_fout, "747\n");
    fflush(_coverage_fout);
    }
    space = ((sizeof(TIFFHeader ) + sizeof(uint16 )) + (unsigned int )dircount * sizeof(TIFFDirEntry )) + sizeof(uint32 );
    {
    fprintf(_coverage_fout, "748\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (*(tif->tif_sizeproc))(tif->tif_clientdata);
    {
    fprintf(_coverage_fout, "749\n");
    fflush(_coverage_fout);
    }
    filesize = tmp___0;
    {
    fprintf(_coverage_fout, "750\n");
    fflush(_coverage_fout);
    }
    dp = dir;
    {
    fprintf(_coverage_fout, "751\n");
    fflush(_coverage_fout);
    }
    n = dircount;
    {
    fprintf(_coverage_fout, "752\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "731\n");
      fflush(_coverage_fout);
      }
      if ((int )n > 0) {
        {
        fprintf(_coverage_fout, "725\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "732\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFDataWidth((enum __anonenum_TIFFDataType_20 )dp->tdir_type);
      {
      fprintf(_coverage_fout, "733\n");
      fflush(_coverage_fout);
      }
      cc = (uint32 )tmp___1;
      {
      fprintf(_coverage_fout, "734\n");
      fflush(_coverage_fout);
      }
      if (cc == 0U) {
        {
        fprintf(_coverage_fout, "726\n");
        fflush(_coverage_fout);
        }
        TIFFErrorExt(tif->tif_clientdata, module___1,
                     "%s: Cannot determine size of unknown tag type %d",
                     tif->tif_name, dp->tdir_type);
        {
        fprintf(_coverage_fout, "727\n");
        fflush(_coverage_fout);
        }
        return (-1);
      } else {
        {
        fprintf(_coverage_fout, "728\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "735\n");
      fflush(_coverage_fout);
      }
      cc *= dp->tdir_count;
      {
      fprintf(_coverage_fout, "736\n");
      fflush(_coverage_fout);
      }
      if (cc > sizeof(uint32 )) {
        {
        fprintf(_coverage_fout, "729\n");
        fflush(_coverage_fout);
        }
        space += cc;
      } else {
        {
        fprintf(_coverage_fout, "730\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "737\n");
      fflush(_coverage_fout);
      }
      n = (uint16 )((int )n - 1);
      {
      fprintf(_coverage_fout, "738\n");
      fflush(_coverage_fout);
      }
      dp ++;
    }
    {
    fprintf(_coverage_fout, "753\n");
    fflush(_coverage_fout);
    }
    space = filesize - space;
    {
    fprintf(_coverage_fout, "754\n");
    fflush(_coverage_fout);
    }
    if ((int )td->td_planarconfig == 2) {
      {
      fprintf(_coverage_fout, "739\n");
      fflush(_coverage_fout);
      }
      space /= (uint32 )td->td_samplesperpixel;
    } else {
      {
      fprintf(_coverage_fout, "740\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "755\n");
    fflush(_coverage_fout);
    }
    i = (unsigned short)0;
    {
    fprintf(_coverage_fout, "756\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "742\n");
      fflush(_coverage_fout);
      }
      if ((tstrip_t )i < td->td_nstrips) {
        {
        fprintf(_coverage_fout, "741\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "743\n");
      fflush(_coverage_fout);
      }
      *(td->td_stripbytecount + i) = space;
      {
      fprintf(_coverage_fout, "744\n");
      fflush(_coverage_fout);
      }
      i = (uint16 )((int )i + 1);
    }
    {
    fprintf(_coverage_fout, "757\n");
    fflush(_coverage_fout);
    }
    i = (uint16 )((int )i - 1);
    {
    fprintf(_coverage_fout, "758\n");
    fflush(_coverage_fout);
    }
    if (*(td->td_stripoffset + i) + *(td->td_stripbytecount + i) > filesize) {
      {
      fprintf(_coverage_fout, "745\n");
      fflush(_coverage_fout);
      }
      *(td->td_stripbytecount + i) = filesize - *(td->td_stripoffset + i);
    } else {
      {
      fprintf(_coverage_fout, "746\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "763\n");
    fflush(_coverage_fout);
    }
    tmp___2 = TIFFScanlineSize(tif);
    {
    fprintf(_coverage_fout, "764\n");
    fflush(_coverage_fout);
    }
    rowbytes = (uint32 )tmp___2;
    {
    fprintf(_coverage_fout, "765\n");
    fflush(_coverage_fout);
    }
    rowsperstrip = td->td_imagelength / td->td_stripsperimage;
    {
    fprintf(_coverage_fout, "766\n");
    fflush(_coverage_fout);
    }
    i = (unsigned short)0;
    {
    fprintf(_coverage_fout, "767\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "760\n");
      fflush(_coverage_fout);
      }
      if ((tstrip_t )i < td->td_nstrips) {
        {
        fprintf(_coverage_fout, "759\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "761\n");
      fflush(_coverage_fout);
      }
      *(td->td_stripbytecount + i) = rowbytes * rowsperstrip;
      {
      fprintf(_coverage_fout, "762\n");
      fflush(_coverage_fout);
      }
      i = (uint16 )((int )i + 1);
    }
  }
  {
  fprintf(_coverage_fout, "775\n");
  fflush(_coverage_fout);
  }
  tif->tif_dir.td_fieldsset[0] |= 1UL << 24;
  {
  fprintf(_coverage_fout, "776\n");
  fflush(_coverage_fout);
  }
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 17))) {
    {
    fprintf(_coverage_fout, "768\n");
    fflush(_coverage_fout);
    }
    td->td_rowsperstrip = td->td_imagelength;
  } else {
    {
    fprintf(_coverage_fout, "769\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "777\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static char const   module___2[16]  = 
  {      (char const   )'M',      (char const   )'i',      (char const   )'s',      (char const   )'s', 
        (char const   )'i',      (char const   )'n',      (char const   )'g',      (char const   )'R', 
        (char const   )'e',      (char const   )'q',      (char const   )'u',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'d',      (char const   )'\000'};
static void MissingRequired(TIFF *tif , char const   *tagname ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "778\n");
  fflush(_coverage_fout);
  }
  TIFFErrorExt(tif->tif_clientdata, module___2,
               "%s: TIFF directory is missing required \"%s\" field",
               tif->tif_name, tagname);
  {
  fprintf(_coverage_fout, "779\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) 
{ TIFFFieldInfo const   *tmp ;
  TIFFFieldInfo const   *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "788\n");
  fflush(_coverage_fout);
  }
  if (count > dir->tdir_count) {
    {
    fprintf(_coverage_fout, "780\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
    {
    fprintf(_coverage_fout, "781\n");
    fflush(_coverage_fout);
    }
    TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "incorrect count for field \"%s\" (%lu, expecting %lu); tag ignored",
                   tmp->field_name, dir->tdir_count, count);
    {
    fprintf(_coverage_fout, "782\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "787\n");
    fflush(_coverage_fout);
    }
    if (count < dir->tdir_count) {
      {
      fprintf(_coverage_fout, "783\n");
      fflush(_coverage_fout);
      }
      tmp___0 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
      {
      fprintf(_coverage_fout, "784\n");
      fflush(_coverage_fout);
      }
      TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "incorrect count for field \"%s\" (%lu, expecting %lu); tag trimmed",
                     tmp___0->field_name, dir->tdir_count, count);
      {
      fprintf(_coverage_fout, "785\n");
      fflush(_coverage_fout);
      }
      return (1);
    } else {
      {
      fprintf(_coverage_fout, "786\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "789\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static tsize_t TIFFFetchData(TIFF *tif , TIFFDirEntry *dir , char *cp ) 
{ int w ;
  int tmp ;
  tsize_t cc ;
  toff_t tmp___0 ;
  tsize_t tmp___1 ;
  tsize_t offset ;
  TIFFFieldInfo const   *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "809\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFDataWidth((enum __anonenum_TIFFDataType_20 )dir->tdir_type);
  {
  fprintf(_coverage_fout, "810\n");
  fflush(_coverage_fout);
  }
  w = tmp;
  {
  fprintf(_coverage_fout, "811\n");
  fflush(_coverage_fout);
  }
  cc = (tsize_t )(dir->tdir_count * (uint32 )w);
  {
  fprintf(_coverage_fout, "812\n");
  fflush(_coverage_fout);
  }
  if (! dir->tdir_count) {
    goto bad;
  } else {
    {
    fprintf(_coverage_fout, "792\n");
    fflush(_coverage_fout);
    }
    if (! w) {
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "791\n");
      fflush(_coverage_fout);
      }
      if ((int )dir->tdir_count / w != cc) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "790\n");
        fflush(_coverage_fout);
        }

      }
    }
  }
  {
  fprintf(_coverage_fout, "813\n");
  fflush(_coverage_fout);
  }
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    {
    fprintf(_coverage_fout, "795\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (*(tif->tif_seekproc))(tif->tif_clientdata, dir->tdir_offset, 0);
    {
    fprintf(_coverage_fout, "796\n");
    fflush(_coverage_fout);
    }
    if (tmp___0 == dir->tdir_offset) {
      {
      fprintf(_coverage_fout, "793\n");
      fflush(_coverage_fout);
      }

    } else {
      goto bad;
    }
    {
    fprintf(_coverage_fout, "797\n");
    fflush(_coverage_fout);
    }
    tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)cp, cc);
    {
    fprintf(_coverage_fout, "798\n");
    fflush(_coverage_fout);
    }
    if (tmp___1 == cc) {
      {
      fprintf(_coverage_fout, "794\n");
      fflush(_coverage_fout);
      }

    } else {
      goto bad;
    }
  } else {
    {
    fprintf(_coverage_fout, "801\n");
    fflush(_coverage_fout);
    }
    offset = (tsize_t )(dir->tdir_offset + (uint32 )cc);
    {
    fprintf(_coverage_fout, "802\n");
    fflush(_coverage_fout);
    }
    if ((int )dir->tdir_offset != offset - cc) {
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "800\n");
      fflush(_coverage_fout);
      }
      if (offset > (int )tif->tif_size) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "799\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "803\n");
    fflush(_coverage_fout);
    }
    _TIFFmemcpy((void *)cp, (void *)(tif->tif_base + dir->tdir_offset), cc);
  }
  {
  fprintf(_coverage_fout, "814\n");
  fflush(_coverage_fout);
  }
  if (tif->tif_flags & 128U) {
    switch ((int )dir->tdir_type) {
    {
    fprintf(_coverage_fout, "804\n");
    fflush(_coverage_fout);
    }
    case 3: 
    case 8: 
    TIFFSwabArrayOfShort((uint16 *)cp, (unsigned long )dir->tdir_count);
    break;
    {
    fprintf(_coverage_fout, "805\n");
    fflush(_coverage_fout);
    }
    case 4: 
    case 9: 
    case 11: 
    TIFFSwabArrayOfLong((uint32 *)cp, (unsigned long )dir->tdir_count);
    break;
    {
    fprintf(_coverage_fout, "806\n");
    fflush(_coverage_fout);
    }
    case 5: 
    case 10: 
    TIFFSwabArrayOfLong((uint32 *)cp, (unsigned long )(2U * dir->tdir_count));
    break;
    {
    fprintf(_coverage_fout, "807\n");
    fflush(_coverage_fout);
    }
    case 12: 
    TIFFSwabArrayOfDouble((double *)cp, (unsigned long )dir->tdir_count);
    break;
    }
  } else {
    {
    fprintf(_coverage_fout, "808\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "815\n");
  fflush(_coverage_fout);
  }
  return (cc);
  {
  fprintf(_coverage_fout, "816\n");
  fflush(_coverage_fout);
  }
  bad: 
  tmp___2 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
  {
  fprintf(_coverage_fout, "817\n");
  fflush(_coverage_fout);
  }
  TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
               "Error fetching data for field \"%s\"", tmp___2->field_name);
  {
  fprintf(_coverage_fout, "818\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static tsize_t TIFFFetchString(TIFF *tif , TIFFDirEntry *dir , char *cp ) 
{ uint32 l ;
  tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "826\n");
  fflush(_coverage_fout);
  }
  if (dir->tdir_count <= 4U) {
    {
    fprintf(_coverage_fout, "821\n");
    fflush(_coverage_fout);
    }
    l = dir->tdir_offset;
    {
    fprintf(_coverage_fout, "822\n");
    fflush(_coverage_fout);
    }
    if (tif->tif_flags & 128U) {
      {
      fprintf(_coverage_fout, "819\n");
      fflush(_coverage_fout);
      }
      TIFFSwabLong(& l);
    } else {
      {
      fprintf(_coverage_fout, "820\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "823\n");
    fflush(_coverage_fout);
    }
    _TIFFmemcpy((void *)cp, (void *)(& l), (int )dir->tdir_count);
    {
    fprintf(_coverage_fout, "824\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "825\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "827\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFFetchData(tif, dir, cp);
  {
  fprintf(_coverage_fout, "828\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cvtRational(TIFF *tif , TIFFDirEntry *dir , uint32 num ,
                       uint32 denom , float *rv ) 
{ TIFFFieldInfo const   *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "836\n");
  fflush(_coverage_fout);
  }
  if (denom == 0U) {
    {
    fprintf(_coverage_fout, "829\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
    {
    fprintf(_coverage_fout, "830\n");
    fflush(_coverage_fout);
    }
    TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                 "%s: Rational with zero denominator (num = %lu)",
                 tmp->field_name, num);
    {
    fprintf(_coverage_fout, "831\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "834\n");
    fflush(_coverage_fout);
    }
    if ((int )dir->tdir_type == 5) {
      {
      fprintf(_coverage_fout, "832\n");
      fflush(_coverage_fout);
      }
      *rv = (float )num / (float )denom;
    } else {
      {
      fprintf(_coverage_fout, "833\n");
      fflush(_coverage_fout);
      }
      *rv = (float )((int )num) / (float )((int )denom);
    }
    {
    fprintf(_coverage_fout, "835\n");
    fflush(_coverage_fout);
    }
    return (1);
  }
}
}
static float TIFFFetchRational(TIFF *tif , TIFFDirEntry *dir ) 
{ uint32 l[2] ;
  float v ;
  tsize_t tmp ;
  int tmp___0 ;
  float tmp___1 ;
  tsize_t tmp___2 ;
  int tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "842\n");
  fflush(_coverage_fout);
  }
  tmp___2 = TIFFFetchData(tif, dir, (char *)(l));
  {
  fprintf(_coverage_fout, "843\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "839\n");
    fflush(_coverage_fout);
    }
    tmp___3 = cvtRational(tif, dir, l[0], l[1], & v);
    {
    fprintf(_coverage_fout, "840\n");
    fflush(_coverage_fout);
    }
    if (tmp___3) {
      {
      fprintf(_coverage_fout, "837\n");
      fflush(_coverage_fout);
      }
      tmp___1 = v;
    } else {
      {
      fprintf(_coverage_fout, "838\n");
      fflush(_coverage_fout);
      }
      tmp___1 = 1.0f;
    }
  } else {
    {
    fprintf(_coverage_fout, "841\n");
    fflush(_coverage_fout);
    }
    tmp___1 = 1.0f;
  }
  {
  fprintf(_coverage_fout, "844\n");
  fflush(_coverage_fout);
  }
  return (tmp___1);
}
}
static float TIFFFetchFloat(TIFF *tif , TIFFDirEntry *dir ) 
{ float v ;
  int32 l ;
  unsigned long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "847\n");
  fflush(_coverage_fout);
  }
  if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
    {
    fprintf(_coverage_fout, "845\n");
    fflush(_coverage_fout);
    }
    tmp = (unsigned long )(dir->tdir_offset >> *(tif->tif_typeshift + dir->tdir_type)) & (unsigned long )*(tif->tif_typemask + dir->tdir_type);
  } else {
    {
    fprintf(_coverage_fout, "846\n");
    fflush(_coverage_fout);
    }
    tmp = (unsigned long )dir->tdir_offset & (unsigned long )*(tif->tif_typemask + dir->tdir_type);
  }
  {
  fprintf(_coverage_fout, "848\n");
  fflush(_coverage_fout);
  }
  l = (int32 )((unsigned int )tmp);
  {
  fprintf(_coverage_fout, "849\n");
  fflush(_coverage_fout);
  }
  _TIFFmemcpy((void *)(& v), (void *)(& l), (int )sizeof(float ));
  {
  fprintf(_coverage_fout, "850\n");
  fflush(_coverage_fout);
  }
  return (v);
}
}
static int TIFFFetchByteArray(TIFF *tif , TIFFDirEntry *dir , uint8 *v ) 
{ tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "873\n");
  fflush(_coverage_fout);
  }
  if (dir->tdir_count <= 4U) {
    {
    fprintf(_coverage_fout, "869\n");
    fflush(_coverage_fout);
    }
    if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
      {
      fprintf(_coverage_fout, "859\n");
      fflush(_coverage_fout);
      }
      if ((int )dir->tdir_type == 6) {
        switch ((int )dir->tdir_count) {
        {
        fprintf(_coverage_fout, "851\n");
        fflush(_coverage_fout);
        }
        case 4: 
        *(v + 3) = (unsigned char )(dir->tdir_offset & 255U);
        {
        fprintf(_coverage_fout, "852\n");
        fflush(_coverage_fout);
        }
        case 3: 
        *(v + 2) = (unsigned char )((dir->tdir_offset >> 8) & 255U);
        {
        fprintf(_coverage_fout, "853\n");
        fflush(_coverage_fout);
        }
        case 2: 
        *(v + 1) = (unsigned char )((dir->tdir_offset >> 16) & 255U);
        {
        fprintf(_coverage_fout, "854\n");
        fflush(_coverage_fout);
        }
        case 1: 
        *(v + 0) = (unsigned char )(dir->tdir_offset >> 24);
        }
      } else {
        switch ((int )dir->tdir_count) {
        {
        fprintf(_coverage_fout, "855\n");
        fflush(_coverage_fout);
        }
        case 4: 
        *(v + 3) = (unsigned char )(dir->tdir_offset & 255U);
        {
        fprintf(_coverage_fout, "856\n");
        fflush(_coverage_fout);
        }
        case 3: 
        *(v + 2) = (unsigned char )((dir->tdir_offset >> 8) & 255U);
        {
        fprintf(_coverage_fout, "857\n");
        fflush(_coverage_fout);
        }
        case 2: 
        *(v + 1) = (unsigned char )((dir->tdir_offset >> 16) & 255U);
        {
        fprintf(_coverage_fout, "858\n");
        fflush(_coverage_fout);
        }
        case 1: 
        *(v + 0) = (unsigned char )(dir->tdir_offset >> 24);
        }
      }
    } else {
      {
      fprintf(_coverage_fout, "868\n");
      fflush(_coverage_fout);
      }
      if ((int )dir->tdir_type == 6) {
        switch ((int )dir->tdir_count) {
        {
        fprintf(_coverage_fout, "860\n");
        fflush(_coverage_fout);
        }
        case 4: 
        *(v + 3) = (unsigned char )(dir->tdir_offset >> 24);
        {
        fprintf(_coverage_fout, "861\n");
        fflush(_coverage_fout);
        }
        case 3: 
        *(v + 2) = (unsigned char )((dir->tdir_offset >> 16) & 255U);
        {
        fprintf(_coverage_fout, "862\n");
        fflush(_coverage_fout);
        }
        case 2: 
        *(v + 1) = (unsigned char )((dir->tdir_offset >> 8) & 255U);
        {
        fprintf(_coverage_fout, "863\n");
        fflush(_coverage_fout);
        }
        case 1: 
        *(v + 0) = (unsigned char )(dir->tdir_offset & 255U);
        }
      } else {
        switch ((int )dir->tdir_count) {
        {
        fprintf(_coverage_fout, "864\n");
        fflush(_coverage_fout);
        }
        case 4: 
        *(v + 3) = (unsigned char )(dir->tdir_offset >> 24);
        {
        fprintf(_coverage_fout, "865\n");
        fflush(_coverage_fout);
        }
        case 3: 
        *(v + 2) = (unsigned char )((dir->tdir_offset >> 16) & 255U);
        {
        fprintf(_coverage_fout, "866\n");
        fflush(_coverage_fout);
        }
        case 2: 
        *(v + 1) = (unsigned char )((dir->tdir_offset >> 8) & 255U);
        {
        fprintf(_coverage_fout, "867\n");
        fflush(_coverage_fout);
        }
        case 1: 
        *(v + 0) = (unsigned char )(dir->tdir_offset & 255U);
        }
      }
    }
    {
    fprintf(_coverage_fout, "870\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "871\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFetchData(tif, dir, (char *)v);
    {
    fprintf(_coverage_fout, "872\n");
    fflush(_coverage_fout);
    }
    return (tmp != 0);
  }
}
}
static int TIFFFetchShortArray(TIFF *tif , TIFFDirEntry *dir , uint16 *v ) 
{ tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "882\n");
  fflush(_coverage_fout);
  }
  if (dir->tdir_count <= 2U) {
    {
    fprintf(_coverage_fout, "878\n");
    fflush(_coverage_fout);
    }
    if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
      switch ((int )dir->tdir_count) {
      {
      fprintf(_coverage_fout, "874\n");
      fflush(_coverage_fout);
      }
      case 2: 
      *(v + 1) = (unsigned short )(dir->tdir_offset & 65535U);
      {
      fprintf(_coverage_fout, "875\n");
      fflush(_coverage_fout);
      }
      case 1: 
      *(v + 0) = (unsigned short )(dir->tdir_offset >> 16);
      }
    } else {
      switch ((int )dir->tdir_count) {
      {
      fprintf(_coverage_fout, "876\n");
      fflush(_coverage_fout);
      }
      case 2: 
      *(v + 1) = (unsigned short )(dir->tdir_offset >> 16);
      {
      fprintf(_coverage_fout, "877\n");
      fflush(_coverage_fout);
      }
      case 1: 
      *(v + 0) = (unsigned short )(dir->tdir_offset & 65535U);
      }
    }
    {
    fprintf(_coverage_fout, "879\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "880\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFetchData(tif, dir, (char *)v);
    {
    fprintf(_coverage_fout, "881\n");
    fflush(_coverage_fout);
    }
    return (tmp != 0);
  }
}
}
static int TIFFFetchShortPair(TIFF *tif , TIFFDirEntry *dir ) 
{ uint8 v[4] ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  uint16 v___0[2] ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  switch ((int )dir->tdir_type) {
  {
  fprintf(_coverage_fout, "893\n");
  fflush(_coverage_fout);
  }
  case 1: 
  case 6: 
  tmp = TIFFFetchByteArray(tif, dir, v);
  {
  fprintf(_coverage_fout, "894\n");
  fflush(_coverage_fout);
  }
  if (tmp) {
    {
    fprintf(_coverage_fout, "885\n");
    fflush(_coverage_fout);
    }
    tmp___0 = TIFFSetField(tif, (unsigned int )dir->tdir_tag, v[0], v[1]);
    {
    fprintf(_coverage_fout, "886\n");
    fflush(_coverage_fout);
    }
    if (tmp___0) {
      {
      fprintf(_coverage_fout, "883\n");
      fflush(_coverage_fout);
      }
      tmp___1 = 1;
    } else {
      {
      fprintf(_coverage_fout, "884\n");
      fflush(_coverage_fout);
      }
      tmp___1 = 0;
    }
  } else {
    {
    fprintf(_coverage_fout, "887\n");
    fflush(_coverage_fout);
    }
    tmp___1 = 0;
  }
  {
  fprintf(_coverage_fout, "895\n");
  fflush(_coverage_fout);
  }
  return (tmp___1);
  {
  fprintf(_coverage_fout, "896\n");
  fflush(_coverage_fout);
  }
  case 3: 
  case 8: 
  tmp___2 = TIFFFetchShortArray(tif, dir, v___0);
  {
  fprintf(_coverage_fout, "897\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "890\n");
    fflush(_coverage_fout);
    }
    tmp___3 = TIFFSetField(tif, (unsigned int )dir->tdir_tag, v___0[0], v___0[1]);
    {
    fprintf(_coverage_fout, "891\n");
    fflush(_coverage_fout);
    }
    if (tmp___3) {
      {
      fprintf(_coverage_fout, "888\n");
      fflush(_coverage_fout);
      }
      tmp___4 = 1;
    } else {
      {
      fprintf(_coverage_fout, "889\n");
      fflush(_coverage_fout);
      }
      tmp___4 = 0;
    }
  } else {
    {
    fprintf(_coverage_fout, "892\n");
    fflush(_coverage_fout);
    }
    tmp___4 = 0;
  }
  {
  fprintf(_coverage_fout, "898\n");
  fflush(_coverage_fout);
  }
  return (tmp___4);
  {
  fprintf(_coverage_fout, "899\n");
  fflush(_coverage_fout);
  }
  default: ;
  {
  fprintf(_coverage_fout, "900\n");
  fflush(_coverage_fout);
  }
  return (0);
  }
}
}
static int TIFFFetchLongArray(TIFF *tif , TIFFDirEntry *dir , uint32 *v ) 
{ tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "905\n");
  fflush(_coverage_fout);
  }
  if (dir->tdir_count == 1U) {
    {
    fprintf(_coverage_fout, "901\n");
    fflush(_coverage_fout);
    }
    *(v + 0) = dir->tdir_offset;
    {
    fprintf(_coverage_fout, "902\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "903\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFetchData(tif, dir, (char *)v);
    {
    fprintf(_coverage_fout, "904\n");
    fflush(_coverage_fout);
    }
    return (tmp != 0);
  }
}
}
static int TIFFFetchRationalArray(TIFF *tif , TIFFDirEntry *dir , float *v ) 
{ int ok ;
  uint32 *l ;
  int tmp ;
  tdata_t tmp___0 ;
  uint32 i ;
  tsize_t tmp___1 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "919\n");
  fflush(_coverage_fout);
  }
  ok = 0;
  {
  fprintf(_coverage_fout, "920\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFDataWidth((enum __anonenum_TIFFDataType_20 )dir->tdir_type);
  {
  fprintf(_coverage_fout, "921\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFCheckMalloc(tif, dir->tdir_count, (unsigned int )tmp,
                             "to fetch array of rationals");
  {
  fprintf(_coverage_fout, "922\n");
  fflush(_coverage_fout);
  }
  l = (uint32 *)tmp___0;
  {
  fprintf(_coverage_fout, "923\n");
  fflush(_coverage_fout);
  }
  if (l) {
    {
    fprintf(_coverage_fout, "915\n");
    fflush(_coverage_fout);
    }
    tmp___1 = TIFFFetchData(tif, dir, (char *)l);
    {
    fprintf(_coverage_fout, "916\n");
    fflush(_coverage_fout);
    }
    if (tmp___1) {
      {
      fprintf(_coverage_fout, "912\n");
      fflush(_coverage_fout);
      }
      i = 0U;
      {
      fprintf(_coverage_fout, "913\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "908\n");
        fflush(_coverage_fout);
        }
        if (i < dir->tdir_count) {
          {
          fprintf(_coverage_fout, "906\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "909\n");
        fflush(_coverage_fout);
        }
        ok = cvtRational(tif, dir, *(l + 2U * i), *(l + (2U * i + 1U)), v + i);
        {
        fprintf(_coverage_fout, "910\n");
        fflush(_coverage_fout);
        }
        if (! ok) {
          break;
        } else {
          {
          fprintf(_coverage_fout, "907\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "911\n");
        fflush(_coverage_fout);
        }
        i ++;
      }
    } else {
      {
      fprintf(_coverage_fout, "914\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "917\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)((char *)l));
  } else {
    {
    fprintf(_coverage_fout, "918\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "924\n");
  fflush(_coverage_fout);
  }
  return (ok);
}
}
static int TIFFFetchFloatArray(TIFF *tif , TIFFDirEntry *dir , float *v ) 
{ tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "931\n");
  fflush(_coverage_fout);
  }
  if (dir->tdir_count == 1U) {
    {
    fprintf(_coverage_fout, "925\n");
    fflush(_coverage_fout);
    }
    *(v + 0) = *((float *)(& dir->tdir_offset));
    {
    fprintf(_coverage_fout, "926\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "929\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFetchData(tif, dir, (char *)v);
    {
    fprintf(_coverage_fout, "930\n");
    fflush(_coverage_fout);
    }
    if (tmp) {
      {
      fprintf(_coverage_fout, "927\n");
      fflush(_coverage_fout);
      }
      return (1);
    } else {
      {
      fprintf(_coverage_fout, "928\n");
      fflush(_coverage_fout);
      }
      return (0);
    }
  }
}
}
static int TIFFFetchDoubleArray(TIFF *tif , TIFFDirEntry *dir , double *v ) 
{ tsize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "934\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFFetchData(tif, dir, (char *)v);
  {
  fprintf(_coverage_fout, "935\n");
  fflush(_coverage_fout);
  }
  if (tmp) {
    {
    fprintf(_coverage_fout, "932\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "933\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
}
}
static int TIFFFetchAnyArray(TIFF *tif , TIFFDirEntry *dir , double *v ) 
{ int i ;
  int tmp ;
  uint8 *vp ;
  int8 *vp___0 ;
  int tmp___0 ;
  uint16 *vp___1 ;
  int16 *vp___2 ;
  int tmp___1 ;
  uint32 *vp___3 ;
  int32 *vp___4 ;
  int tmp___2 ;
  float *vp___5 ;
  int tmp___3 ;
  float *vp___6 ;
  int tmp___4 ;
  TIFFFieldInfo const   *tmp___5 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  switch ((int )dir->tdir_type) {
  {
  fprintf(_coverage_fout, "996\n");
  fflush(_coverage_fout);
  }
  case 1: 
  case 6: 
  tmp = TIFFFetchByteArray(tif, dir, (uint8 *)v);
  {
  fprintf(_coverage_fout, "997\n");
  fflush(_coverage_fout);
  }
  if (tmp) {
    {
    fprintf(_coverage_fout, "936\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "937\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
  {
  fprintf(_coverage_fout, "998\n");
  fflush(_coverage_fout);
  }
  if ((int )dir->tdir_type == 1) {
    {
    fprintf(_coverage_fout, "942\n");
    fflush(_coverage_fout);
    }
    vp = (uint8 *)v;
    {
    fprintf(_coverage_fout, "943\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "944\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "939\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "938\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "940\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp + i);
      {
      fprintf(_coverage_fout, "941\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  } else {
    {
    fprintf(_coverage_fout, "949\n");
    fflush(_coverage_fout);
    }
    vp___0 = (int8 *)v;
    {
    fprintf(_coverage_fout, "950\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "951\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "946\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "945\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "947\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp___0 + i);
      {
      fprintf(_coverage_fout, "948\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  }
  break;
  {
  fprintf(_coverage_fout, "999\n");
  fflush(_coverage_fout);
  }
  case 3: 
  case 8: 
  tmp___0 = TIFFFetchShortArray(tif, dir, (uint16 *)v);
  {
  fprintf(_coverage_fout, "1000\n");
  fflush(_coverage_fout);
  }
  if (tmp___0) {
    {
    fprintf(_coverage_fout, "952\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "953\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
  {
  fprintf(_coverage_fout, "1001\n");
  fflush(_coverage_fout);
  }
  if ((int )dir->tdir_type == 3) {
    {
    fprintf(_coverage_fout, "958\n");
    fflush(_coverage_fout);
    }
    vp___1 = (uint16 *)v;
    {
    fprintf(_coverage_fout, "959\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "960\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "955\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "954\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "956\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp___1 + i);
      {
      fprintf(_coverage_fout, "957\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  } else {
    {
    fprintf(_coverage_fout, "965\n");
    fflush(_coverage_fout);
    }
    vp___2 = (int16 *)v;
    {
    fprintf(_coverage_fout, "966\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "967\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "962\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "961\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "963\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp___2 + i);
      {
      fprintf(_coverage_fout, "964\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  }
  break;
  {
  fprintf(_coverage_fout, "1002\n");
  fflush(_coverage_fout);
  }
  case 4: 
  case 9: 
  tmp___1 = TIFFFetchLongArray(tif, dir, (uint32 *)v);
  {
  fprintf(_coverage_fout, "1003\n");
  fflush(_coverage_fout);
  }
  if (tmp___1) {
    {
    fprintf(_coverage_fout, "968\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "969\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
  {
  fprintf(_coverage_fout, "1004\n");
  fflush(_coverage_fout);
  }
  if ((int )dir->tdir_type == 4) {
    {
    fprintf(_coverage_fout, "974\n");
    fflush(_coverage_fout);
    }
    vp___3 = (uint32 *)v;
    {
    fprintf(_coverage_fout, "975\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "976\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "971\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "970\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "972\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp___3 + i);
      {
      fprintf(_coverage_fout, "973\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  } else {
    {
    fprintf(_coverage_fout, "981\n");
    fflush(_coverage_fout);
    }
    vp___4 = (int32 *)v;
    {
    fprintf(_coverage_fout, "982\n");
    fflush(_coverage_fout);
    }
    i = (int )(dir->tdir_count - 1U);
    {
    fprintf(_coverage_fout, "983\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "978\n");
      fflush(_coverage_fout);
      }
      if (i >= 0) {
        {
        fprintf(_coverage_fout, "977\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "979\n");
      fflush(_coverage_fout);
      }
      *(v + i) = (double )*(vp___4 + i);
      {
      fprintf(_coverage_fout, "980\n");
      fflush(_coverage_fout);
      }
      i --;
    }
  }
  break;
  {
  fprintf(_coverage_fout, "1005\n");
  fflush(_coverage_fout);
  }
  case 5: 
  case 10: 
  tmp___2 = TIFFFetchRationalArray(tif, dir, (float *)v);
  {
  fprintf(_coverage_fout, "1006\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "984\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "985\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
  {
  fprintf(_coverage_fout, "1007\n");
  fflush(_coverage_fout);
  }
  vp___5 = (float *)v;
  {
  fprintf(_coverage_fout, "1008\n");
  fflush(_coverage_fout);
  }
  i = (int )(dir->tdir_count - 1U);
  {
  fprintf(_coverage_fout, "1009\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "987\n");
    fflush(_coverage_fout);
    }
    if (i >= 0) {
      {
      fprintf(_coverage_fout, "986\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "988\n");
    fflush(_coverage_fout);
    }
    *(v + i) = (double )*(vp___5 + i);
    {
    fprintf(_coverage_fout, "989\n");
    fflush(_coverage_fout);
    }
    i --;
  }
  break;
  {
  fprintf(_coverage_fout, "1010\n");
  fflush(_coverage_fout);
  }
  case 11: 
  tmp___3 = TIFFFetchFloatArray(tif, dir, (float *)v);
  {
  fprintf(_coverage_fout, "1011\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "990\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "991\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
  {
  fprintf(_coverage_fout, "1012\n");
  fflush(_coverage_fout);
  }
  vp___6 = (float *)v;
  {
  fprintf(_coverage_fout, "1013\n");
  fflush(_coverage_fout);
  }
  i = (int )(dir->tdir_count - 1U);
  {
  fprintf(_coverage_fout, "1014\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "993\n");
    fflush(_coverage_fout);
    }
    if (i >= 0) {
      {
      fprintf(_coverage_fout, "992\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "994\n");
    fflush(_coverage_fout);
    }
    *(v + i) = (double )*(vp___6 + i);
    {
    fprintf(_coverage_fout, "995\n");
    fflush(_coverage_fout);
    }
    i --;
  }
  break;
  {
  fprintf(_coverage_fout, "1015\n");
  fflush(_coverage_fout);
  }
  case 12: 
  tmp___4 = TIFFFetchDoubleArray(tif, dir, v);
  {
  fprintf(_coverage_fout, "1016\n");
  fflush(_coverage_fout);
  }
  return (tmp___4);
  {
  fprintf(_coverage_fout, "1017\n");
  fflush(_coverage_fout);
  }
  default: 
  tmp___5 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
  {
  fprintf(_coverage_fout, "1018\n");
  fflush(_coverage_fout);
  }
  TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
               "cannot read TIFF_ANY type %d for field \"%s\"",
               tmp___5->field_name);
  {
  fprintf(_coverage_fout, "1019\n");
  fflush(_coverage_fout);
  }
  return (0);
  }
  {
  fprintf(_coverage_fout, "1020\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static char const   mesg[19]  = 
  {      (char const   )'t',      (char const   )'o',      (char const   )' ',      (char const   )'f', 
        (char const   )'e',      (char const   )'t',      (char const   )'c',      (char const   )'h', 
        (char const   )' ',      (char const   )'t',      (char const   )'a',      (char const   )'g', 
        (char const   )' ',      (char const   )'v',      (char const   )'a',      (char const   )'l', 
        (char const   )'u',      (char const   )'e',      (char const   )'\000'};
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp ) 
{ int ok ;
  TIFFFieldInfo const   *fip ;
  TIFFFieldInfo const   *tmp ;
  char *cp ;
  tdata_t tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  tdata_t tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  tdata_t tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  tdata_t tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  tdata_t tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  tdata_t tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  tdata_t tmp___18 ;
  tsize_t tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  TIFFDataType type ;
  uint16 v ;
  unsigned long tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  uint32 v32 ;
  unsigned long tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  float v___0 ;
  float tmp___29 ;
  float tmp___30 ;
  float tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  double v___1 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  char c[2] ;
  int tmp___39 ;
  int tmp___40 ;
  tsize_t tmp___41 ;
  int tmp___42 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1157\n");
  fflush(_coverage_fout);
  }
  ok = 0;
  {
  fprintf(_coverage_fout, "1158\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFFieldWithTag(tif, (unsigned int )dp->tdir_tag);
  {
  fprintf(_coverage_fout, "1159\n");
  fflush(_coverage_fout);
  }
  fip = tmp;
  {
  fprintf(_coverage_fout, "1160\n");
  fflush(_coverage_fout);
  }
  if (dp->tdir_count > 1U) {
    {
    fprintf(_coverage_fout, "1095\n");
    fflush(_coverage_fout);
    }
    cp = (char *)((void *)0);
    switch ((int )dp->tdir_type) {
    {
    fprintf(_coverage_fout, "1058\n");
    fflush(_coverage_fout);
    }
    case 1: 
    case 6: 
    tmp___0 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(uint8 ), mesg);
    {
    fprintf(_coverage_fout, "1059\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___0;
    {
    fprintf(_coverage_fout, "1060\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1023\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFFetchByteArray(tif, dp, (uint8 *)cp);
      {
      fprintf(_coverage_fout, "1024\n");
      fflush(_coverage_fout);
      }
      if (tmp___1) {
        {
        fprintf(_coverage_fout, "1021\n");
        fflush(_coverage_fout);
        }
        tmp___2 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1022\n");
        fflush(_coverage_fout);
        }
        tmp___2 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1025\n");
      fflush(_coverage_fout);
      }
      tmp___2 = 0;
    }
    {
    fprintf(_coverage_fout, "1061\n");
    fflush(_coverage_fout);
    }
    ok = tmp___2;
    break;
    {
    fprintf(_coverage_fout, "1062\n");
    fflush(_coverage_fout);
    }
    case 3: 
    case 8: 
    tmp___3 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(uint16 ), mesg);
    {
    fprintf(_coverage_fout, "1063\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___3;
    {
    fprintf(_coverage_fout, "1064\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1028\n");
      fflush(_coverage_fout);
      }
      tmp___4 = TIFFFetchShortArray(tif, dp, (uint16 *)cp);
      {
      fprintf(_coverage_fout, "1029\n");
      fflush(_coverage_fout);
      }
      if (tmp___4) {
        {
        fprintf(_coverage_fout, "1026\n");
        fflush(_coverage_fout);
        }
        tmp___5 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1027\n");
        fflush(_coverage_fout);
        }
        tmp___5 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1030\n");
      fflush(_coverage_fout);
      }
      tmp___5 = 0;
    }
    {
    fprintf(_coverage_fout, "1065\n");
    fflush(_coverage_fout);
    }
    ok = tmp___5;
    break;
    {
    fprintf(_coverage_fout, "1066\n");
    fflush(_coverage_fout);
    }
    case 4: 
    case 9: 
    tmp___6 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(uint32 ), mesg);
    {
    fprintf(_coverage_fout, "1067\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___6;
    {
    fprintf(_coverage_fout, "1068\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1033\n");
      fflush(_coverage_fout);
      }
      tmp___7 = TIFFFetchLongArray(tif, dp, (uint32 *)cp);
      {
      fprintf(_coverage_fout, "1034\n");
      fflush(_coverage_fout);
      }
      if (tmp___7) {
        {
        fprintf(_coverage_fout, "1031\n");
        fflush(_coverage_fout);
        }
        tmp___8 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1032\n");
        fflush(_coverage_fout);
        }
        tmp___8 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1035\n");
      fflush(_coverage_fout);
      }
      tmp___8 = 0;
    }
    {
    fprintf(_coverage_fout, "1069\n");
    fflush(_coverage_fout);
    }
    ok = tmp___8;
    break;
    {
    fprintf(_coverage_fout, "1070\n");
    fflush(_coverage_fout);
    }
    case 5: 
    case 10: 
    tmp___9 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(float ), mesg);
    {
    fprintf(_coverage_fout, "1071\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___9;
    {
    fprintf(_coverage_fout, "1072\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1038\n");
      fflush(_coverage_fout);
      }
      tmp___10 = TIFFFetchRationalArray(tif, dp, (float *)cp);
      {
      fprintf(_coverage_fout, "1039\n");
      fflush(_coverage_fout);
      }
      if (tmp___10) {
        {
        fprintf(_coverage_fout, "1036\n");
        fflush(_coverage_fout);
        }
        tmp___11 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1037\n");
        fflush(_coverage_fout);
        }
        tmp___11 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1040\n");
      fflush(_coverage_fout);
      }
      tmp___11 = 0;
    }
    {
    fprintf(_coverage_fout, "1073\n");
    fflush(_coverage_fout);
    }
    ok = tmp___11;
    break;
    {
    fprintf(_coverage_fout, "1074\n");
    fflush(_coverage_fout);
    }
    case 11: 
    tmp___12 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(float ), mesg);
    {
    fprintf(_coverage_fout, "1075\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___12;
    {
    fprintf(_coverage_fout, "1076\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1043\n");
      fflush(_coverage_fout);
      }
      tmp___13 = TIFFFetchFloatArray(tif, dp, (float *)cp);
      {
      fprintf(_coverage_fout, "1044\n");
      fflush(_coverage_fout);
      }
      if (tmp___13) {
        {
        fprintf(_coverage_fout, "1041\n");
        fflush(_coverage_fout);
        }
        tmp___14 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1042\n");
        fflush(_coverage_fout);
        }
        tmp___14 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1045\n");
      fflush(_coverage_fout);
      }
      tmp___14 = 0;
    }
    {
    fprintf(_coverage_fout, "1077\n");
    fflush(_coverage_fout);
    }
    ok = tmp___14;
    break;
    {
    fprintf(_coverage_fout, "1078\n");
    fflush(_coverage_fout);
    }
    case 12: 
    tmp___15 = _TIFFCheckMalloc(tif, dp->tdir_count, sizeof(double ), mesg);
    {
    fprintf(_coverage_fout, "1079\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___15;
    {
    fprintf(_coverage_fout, "1080\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1048\n");
      fflush(_coverage_fout);
      }
      tmp___16 = TIFFFetchDoubleArray(tif, dp, (double *)cp);
      {
      fprintf(_coverage_fout, "1049\n");
      fflush(_coverage_fout);
      }
      if (tmp___16) {
        {
        fprintf(_coverage_fout, "1046\n");
        fflush(_coverage_fout);
        }
        tmp___17 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1047\n");
        fflush(_coverage_fout);
        }
        tmp___17 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1050\n");
      fflush(_coverage_fout);
      }
      tmp___17 = 0;
    }
    {
    fprintf(_coverage_fout, "1081\n");
    fflush(_coverage_fout);
    }
    ok = tmp___17;
    break;
    {
    fprintf(_coverage_fout, "1082\n");
    fflush(_coverage_fout);
    }
    case 2: 
    case 7: 
    tmp___18 = _TIFFCheckMalloc(tif, dp->tdir_count + 1U, 1U, mesg);
    {
    fprintf(_coverage_fout, "1083\n");
    fflush(_coverage_fout);
    }
    cp = (char *)tmp___18;
    {
    fprintf(_coverage_fout, "1084\n");
    fflush(_coverage_fout);
    }
    if (cp) {
      {
      fprintf(_coverage_fout, "1053\n");
      fflush(_coverage_fout);
      }
      tmp___19 = TIFFFetchString(tif, dp, cp);
      {
      fprintf(_coverage_fout, "1054\n");
      fflush(_coverage_fout);
      }
      if (tmp___19) {
        {
        fprintf(_coverage_fout, "1051\n");
        fflush(_coverage_fout);
        }
        tmp___20 = 1;
      } else {
        {
        fprintf(_coverage_fout, "1052\n");
        fflush(_coverage_fout);
        }
        tmp___20 = 0;
      }
    } else {
      {
      fprintf(_coverage_fout, "1055\n");
      fflush(_coverage_fout);
      }
      tmp___20 = 0;
    }
    {
    fprintf(_coverage_fout, "1085\n");
    fflush(_coverage_fout);
    }
    ok = tmp___20;
    {
    fprintf(_coverage_fout, "1086\n");
    fflush(_coverage_fout);
    }
    if (ok != 0) {
      {
      fprintf(_coverage_fout, "1056\n");
      fflush(_coverage_fout);
      }
      *(cp + dp->tdir_count) = (char )'\000';
    } else {
      {
      fprintf(_coverage_fout, "1057\n");
      fflush(_coverage_fout);
      }

    }
    break;
    }
    {
    fprintf(_coverage_fout, "1096\n");
    fflush(_coverage_fout);
    }
    if (ok) {
      {
      fprintf(_coverage_fout, "1091\n");
      fflush(_coverage_fout);
      }
      if (fip->field_passcount) {
        {
        fprintf(_coverage_fout, "1087\n");
        fflush(_coverage_fout);
        }
        tmp___21 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                                dp->tdir_count, cp);
        {
        fprintf(_coverage_fout, "1088\n");
        fflush(_coverage_fout);
        }
        ok = tmp___21;
      } else {
        {
        fprintf(_coverage_fout, "1089\n");
        fflush(_coverage_fout);
        }
        tmp___22 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, cp);
        {
        fprintf(_coverage_fout, "1090\n");
        fflush(_coverage_fout);
        }
        ok = tmp___22;
      }
    } else {
      {
      fprintf(_coverage_fout, "1092\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1097\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )cp != (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "1093\n");
      fflush(_coverage_fout);
      }
      _TIFFfree((void *)cp);
    } else {
      {
      fprintf(_coverage_fout, "1094\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1155\n");
    fflush(_coverage_fout);
    }
    tmp___42 = CheckDirCount(tif, dp, 1U);
    {
    fprintf(_coverage_fout, "1156\n");
    fflush(_coverage_fout);
    }
    if (tmp___42) {
      switch ((int )dp->tdir_type) {
      {
      fprintf(_coverage_fout, "1140\n");
      fflush(_coverage_fout);
      }
      case 1: 
      case 6: 
      case 3: 
      case 8: 
      type = (TIFFDataType )fip->field_type;
      {
      fprintf(_coverage_fout, "1141\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )type != 4U) {
        {
        fprintf(_coverage_fout, "1108\n");
        fflush(_coverage_fout);
        }
        if ((unsigned int )type != 9U) {
          {
          fprintf(_coverage_fout, "1104\n");
          fflush(_coverage_fout);
          }
          if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
            {
            fprintf(_coverage_fout, "1098\n");
            fflush(_coverage_fout);
            }
            tmp___23 = (unsigned long )(dp->tdir_offset >> *(tif->tif_typeshift + dp->tdir_type)) & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
          } else {
            {
            fprintf(_coverage_fout, "1099\n");
            fflush(_coverage_fout);
            }
            tmp___23 = (unsigned long )dp->tdir_offset & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
          }
          {
          fprintf(_coverage_fout, "1105\n");
          fflush(_coverage_fout);
          }
          v = (unsigned short )((unsigned int )tmp___23);
          {
          fprintf(_coverage_fout, "1106\n");
          fflush(_coverage_fout);
          }
          if (fip->field_passcount) {
            {
            fprintf(_coverage_fout, "1100\n");
            fflush(_coverage_fout);
            }
            tmp___24 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, 1, & v);
            {
            fprintf(_coverage_fout, "1101\n");
            fflush(_coverage_fout);
            }
            ok = tmp___24;
          } else {
            {
            fprintf(_coverage_fout, "1102\n");
            fflush(_coverage_fout);
            }
            tmp___25 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, v);
            {
            fprintf(_coverage_fout, "1103\n");
            fflush(_coverage_fout);
            }
            ok = tmp___25;
          }
          break;
        } else {
          {
          fprintf(_coverage_fout, "1107\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1109\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1142\n");
      fflush(_coverage_fout);
      }
      case 4: 
      case 9: 
      if ((int )tif->tif_header.tiff_magic == 0x4d4d) {
        {
        fprintf(_coverage_fout, "1110\n");
        fflush(_coverage_fout);
        }
        tmp___26 = (unsigned long )(dp->tdir_offset >> *(tif->tif_typeshift + dp->tdir_type)) & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      } else {
        {
        fprintf(_coverage_fout, "1111\n");
        fflush(_coverage_fout);
        }
        tmp___26 = (unsigned long )dp->tdir_offset & (unsigned long )*(tif->tif_typemask + dp->tdir_type);
      }
      {
      fprintf(_coverage_fout, "1143\n");
      fflush(_coverage_fout);
      }
      v32 = (unsigned int )tmp___26;
      {
      fprintf(_coverage_fout, "1144\n");
      fflush(_coverage_fout);
      }
      if (fip->field_passcount) {
        {
        fprintf(_coverage_fout, "1112\n");
        fflush(_coverage_fout);
        }
        tmp___27 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, 1, & v32);
        {
        fprintf(_coverage_fout, "1113\n");
        fflush(_coverage_fout);
        }
        ok = tmp___27;
      } else {
        {
        fprintf(_coverage_fout, "1114\n");
        fflush(_coverage_fout);
        }
        tmp___28 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, v32);
        {
        fprintf(_coverage_fout, "1115\n");
        fflush(_coverage_fout);
        }
        ok = tmp___28;
      }
      break;
      {
      fprintf(_coverage_fout, "1145\n");
      fflush(_coverage_fout);
      }
      case 5: 
      case 10: 
      case 11: 
      if ((int )dp->tdir_type == 11) {
        {
        fprintf(_coverage_fout, "1116\n");
        fflush(_coverage_fout);
        }
        tmp___29 = TIFFFetchFloat(tif, dp);
        {
        fprintf(_coverage_fout, "1117\n");
        fflush(_coverage_fout);
        }
        tmp___31 = tmp___29;
      } else {
        {
        fprintf(_coverage_fout, "1118\n");
        fflush(_coverage_fout);
        }
        tmp___30 = TIFFFetchRational(tif, dp);
        {
        fprintf(_coverage_fout, "1119\n");
        fflush(_coverage_fout);
        }
        tmp___31 = tmp___30;
      }
      {
      fprintf(_coverage_fout, "1146\n");
      fflush(_coverage_fout);
      }
      v___0 = tmp___31;
      {
      fprintf(_coverage_fout, "1147\n");
      fflush(_coverage_fout);
      }
      if (fip->field_passcount) {
        {
        fprintf(_coverage_fout, "1120\n");
        fflush(_coverage_fout);
        }
        tmp___32 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, 1, & v___0);
        {
        fprintf(_coverage_fout, "1121\n");
        fflush(_coverage_fout);
        }
        ok = tmp___32;
      } else {
        {
        fprintf(_coverage_fout, "1122\n");
        fflush(_coverage_fout);
        }
        tmp___33 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, v___0);
        {
        fprintf(_coverage_fout, "1123\n");
        fflush(_coverage_fout);
        }
        ok = tmp___33;
      }
      break;
      {
      fprintf(_coverage_fout, "1148\n");
      fflush(_coverage_fout);
      }
      case 12: 
      tmp___34 = TIFFFetchDoubleArray(tif, dp, & v___1);
      {
      fprintf(_coverage_fout, "1149\n");
      fflush(_coverage_fout);
      }
      if (tmp___34) {
        {
        fprintf(_coverage_fout, "1130\n");
        fflush(_coverage_fout);
        }
        if (fip->field_passcount) {
          {
          fprintf(_coverage_fout, "1124\n");
          fflush(_coverage_fout);
          }
          tmp___35 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, 1, & v___1);
          {
          fprintf(_coverage_fout, "1125\n");
          fflush(_coverage_fout);
          }
          tmp___37 = tmp___35;
        } else {
          {
          fprintf(_coverage_fout, "1126\n");
          fflush(_coverage_fout);
          }
          tmp___36 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, v___1);
          {
          fprintf(_coverage_fout, "1127\n");
          fflush(_coverage_fout);
          }
          tmp___37 = tmp___36;
        }
        {
        fprintf(_coverage_fout, "1131\n");
        fflush(_coverage_fout);
        }
        if (tmp___37) {
          {
          fprintf(_coverage_fout, "1128\n");
          fflush(_coverage_fout);
          }
          tmp___38 = 1;
        } else {
          {
          fprintf(_coverage_fout, "1129\n");
          fflush(_coverage_fout);
          }
          tmp___38 = 0;
        }
      } else {
        {
        fprintf(_coverage_fout, "1132\n");
        fflush(_coverage_fout);
        }
        tmp___38 = 0;
      }
      {
      fprintf(_coverage_fout, "1150\n");
      fflush(_coverage_fout);
      }
      ok = tmp___38;
      break;
      {
      fprintf(_coverage_fout, "1151\n");
      fflush(_coverage_fout);
      }
      case 2: 
      case 7: 
      tmp___41 = TIFFFetchString(tif, dp, c);
      {
      fprintf(_coverage_fout, "1152\n");
      fflush(_coverage_fout);
      }
      ok = tmp___41 != 0;
      {
      fprintf(_coverage_fout, "1153\n");
      fflush(_coverage_fout);
      }
      if (ok != 0) {
        {
        fprintf(_coverage_fout, "1137\n");
        fflush(_coverage_fout);
        }
        c[1] = (char )'\000';
        {
        fprintf(_coverage_fout, "1138\n");
        fflush(_coverage_fout);
        }
        if (fip->field_passcount) {
          {
          fprintf(_coverage_fout, "1133\n");
          fflush(_coverage_fout);
          }
          tmp___39 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, 1, c);
          {
          fprintf(_coverage_fout, "1134\n");
          fflush(_coverage_fout);
          }
          ok = tmp___39;
        } else {
          {
          fprintf(_coverage_fout, "1135\n");
          fflush(_coverage_fout);
          }
          tmp___40 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, c);
          {
          fprintf(_coverage_fout, "1136\n");
          fflush(_coverage_fout);
          }
          ok = tmp___40;
        }
      } else {
        {
        fprintf(_coverage_fout, "1139\n");
        fflush(_coverage_fout);
        }

      }
      break;
      }
    } else {
      {
      fprintf(_coverage_fout, "1154\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "1161\n");
  fflush(_coverage_fout);
  }
  return (ok);
}
}
static int TIFFFetchPerSampleShorts(TIFF *tif , TIFFDirEntry *dir , uint16 *pl ) 
{ uint16 samples ;
  int status ;
  uint16 buf[10] ;
  uint16 *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1193\n");
  fflush(_coverage_fout);
  }
  samples = tif->tif_dir.td_samplesperpixel;
  {
  fprintf(_coverage_fout, "1194\n");
  fflush(_coverage_fout);
  }
  status = 0;
  {
  fprintf(_coverage_fout, "1195\n");
  fflush(_coverage_fout);
  }
  tmp___2 = CheckDirCount(tif, dir, (unsigned int )samples);
  {
  fprintf(_coverage_fout, "1196\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "1188\n");
    fflush(_coverage_fout);
    }
    v = buf;
    {
    fprintf(_coverage_fout, "1189\n");
    fflush(_coverage_fout);
    }
    if (dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      {
      fprintf(_coverage_fout, "1162\n");
      fflush(_coverage_fout);
      }
      tmp = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(uint16 ),
                             "to fetch per-sample values");
      {
      fprintf(_coverage_fout, "1163\n");
      fflush(_coverage_fout);
      }
      v = (uint16 *)tmp;
    } else {
      {
      fprintf(_coverage_fout, "1164\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1190\n");
    fflush(_coverage_fout);
    }
    if (v) {
      {
      fprintf(_coverage_fout, "1181\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFFetchShortArray(tif, dir, v);
      {
      fprintf(_coverage_fout, "1182\n");
      fflush(_coverage_fout);
      }
      if (tmp___1) {
        {
        fprintf(_coverage_fout, "1174\n");
        fflush(_coverage_fout);
        }
        check_count = (int )dir->tdir_count;
        {
        fprintf(_coverage_fout, "1175\n");
        fflush(_coverage_fout);
        }
        if ((int )samples < check_count) {
          {
          fprintf(_coverage_fout, "1165\n");
          fflush(_coverage_fout);
          }
          check_count = (int )samples;
        } else {
          {
          fprintf(_coverage_fout, "1166\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1176\n");
        fflush(_coverage_fout);
        }
        i = (unsigned short)1;
        {
        fprintf(_coverage_fout, "1177\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "1171\n");
          fflush(_coverage_fout);
          }
          if ((int )i < check_count) {
            {
            fprintf(_coverage_fout, "1167\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "1172\n");
          fflush(_coverage_fout);
          }
          if ((int )*(v + i) != (int )*(v + 0)) {
            {
            fprintf(_coverage_fout, "1168\n");
            fflush(_coverage_fout);
            }
            tmp___0 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
            {
            fprintf(_coverage_fout, "1169\n");
            fflush(_coverage_fout);
            }
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {
            {
            fprintf(_coverage_fout, "1170\n");
            fflush(_coverage_fout);
            }

          }
          {
          fprintf(_coverage_fout, "1173\n");
          fflush(_coverage_fout);
          }
          i = (uint16 )((int )i + 1);
        }
        {
        fprintf(_coverage_fout, "1178\n");
        fflush(_coverage_fout);
        }
        *pl = *(v + 0);
        {
        fprintf(_coverage_fout, "1179\n");
        fflush(_coverage_fout);
        }
        status = 1;
      } else {
        {
        fprintf(_coverage_fout, "1180\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1183\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1191\n");
    fflush(_coverage_fout);
    }
    bad: 
    if (v) {
      {
      fprintf(_coverage_fout, "1186\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )v != (unsigned int )(buf)) {
        {
        fprintf(_coverage_fout, "1184\n");
        fflush(_coverage_fout);
        }
        _TIFFfree((void *)v);
      } else {
        {
        fprintf(_coverage_fout, "1185\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1187\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1192\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1197\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int TIFFFetchPerSampleLongs(TIFF *tif , TIFFDirEntry *dir , uint32 *pl ) 
{ uint16 samples ;
  int status ;
  uint32 buf[10] ;
  uint32 *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1229\n");
  fflush(_coverage_fout);
  }
  samples = tif->tif_dir.td_samplesperpixel;
  {
  fprintf(_coverage_fout, "1230\n");
  fflush(_coverage_fout);
  }
  status = 0;
  {
  fprintf(_coverage_fout, "1231\n");
  fflush(_coverage_fout);
  }
  tmp___2 = CheckDirCount(tif, dir, (unsigned int )samples);
  {
  fprintf(_coverage_fout, "1232\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "1224\n");
    fflush(_coverage_fout);
    }
    v = buf;
    {
    fprintf(_coverage_fout, "1225\n");
    fflush(_coverage_fout);
    }
    if (dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      {
      fprintf(_coverage_fout, "1198\n");
      fflush(_coverage_fout);
      }
      tmp = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(uint32 ),
                             "to fetch per-sample values");
      {
      fprintf(_coverage_fout, "1199\n");
      fflush(_coverage_fout);
      }
      v = (uint32 *)tmp;
    } else {
      {
      fprintf(_coverage_fout, "1200\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1226\n");
    fflush(_coverage_fout);
    }
    if (v) {
      {
      fprintf(_coverage_fout, "1217\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFFetchLongArray(tif, dir, v);
      {
      fprintf(_coverage_fout, "1218\n");
      fflush(_coverage_fout);
      }
      if (tmp___1) {
        {
        fprintf(_coverage_fout, "1210\n");
        fflush(_coverage_fout);
        }
        check_count = (int )dir->tdir_count;
        {
        fprintf(_coverage_fout, "1211\n");
        fflush(_coverage_fout);
        }
        if ((int )samples < check_count) {
          {
          fprintf(_coverage_fout, "1201\n");
          fflush(_coverage_fout);
          }
          check_count = (int )samples;
        } else {
          {
          fprintf(_coverage_fout, "1202\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1212\n");
        fflush(_coverage_fout);
        }
        i = (unsigned short)1;
        {
        fprintf(_coverage_fout, "1213\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "1207\n");
          fflush(_coverage_fout);
          }
          if ((int )i < check_count) {
            {
            fprintf(_coverage_fout, "1203\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "1208\n");
          fflush(_coverage_fout);
          }
          if (*(v + i) != *(v + 0)) {
            {
            fprintf(_coverage_fout, "1204\n");
            fflush(_coverage_fout);
            }
            tmp___0 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
            {
            fprintf(_coverage_fout, "1205\n");
            fflush(_coverage_fout);
            }
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {
            {
            fprintf(_coverage_fout, "1206\n");
            fflush(_coverage_fout);
            }

          }
          {
          fprintf(_coverage_fout, "1209\n");
          fflush(_coverage_fout);
          }
          i = (uint16 )((int )i + 1);
        }
        {
        fprintf(_coverage_fout, "1214\n");
        fflush(_coverage_fout);
        }
        *pl = *(v + 0);
        {
        fprintf(_coverage_fout, "1215\n");
        fflush(_coverage_fout);
        }
        status = 1;
      } else {
        {
        fprintf(_coverage_fout, "1216\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1219\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1227\n");
    fflush(_coverage_fout);
    }
    bad: 
    if (v) {
      {
      fprintf(_coverage_fout, "1222\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )v != (unsigned int )(buf)) {
        {
        fprintf(_coverage_fout, "1220\n");
        fflush(_coverage_fout);
        }
        _TIFFfree((void *)v);
      } else {
        {
        fprintf(_coverage_fout, "1221\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1223\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1228\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1233\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int TIFFFetchPerSampleAnys(TIFF *tif , TIFFDirEntry *dir , double *pl ) 
{ uint16 samples ;
  int status ;
  double buf[10] ;
  double *v ;
  tdata_t tmp ;
  uint16 i ;
  int check_count ;
  TIFFFieldInfo const   *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1265\n");
  fflush(_coverage_fout);
  }
  samples = tif->tif_dir.td_samplesperpixel;
  {
  fprintf(_coverage_fout, "1266\n");
  fflush(_coverage_fout);
  }
  status = 0;
  {
  fprintf(_coverage_fout, "1267\n");
  fflush(_coverage_fout);
  }
  tmp___2 = CheckDirCount(tif, dir, (unsigned int )samples);
  {
  fprintf(_coverage_fout, "1268\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "1260\n");
    fflush(_coverage_fout);
    }
    v = buf;
    {
    fprintf(_coverage_fout, "1261\n");
    fflush(_coverage_fout);
    }
    if (dir->tdir_count > sizeof(buf) / sizeof(buf[0])) {
      {
      fprintf(_coverage_fout, "1234\n");
      fflush(_coverage_fout);
      }
      tmp = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(double ),
                             "to fetch per-sample values");
      {
      fprintf(_coverage_fout, "1235\n");
      fflush(_coverage_fout);
      }
      v = (double *)tmp;
    } else {
      {
      fprintf(_coverage_fout, "1236\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1262\n");
    fflush(_coverage_fout);
    }
    if (v) {
      {
      fprintf(_coverage_fout, "1253\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFFetchAnyArray(tif, dir, v);
      {
      fprintf(_coverage_fout, "1254\n");
      fflush(_coverage_fout);
      }
      if (tmp___1) {
        {
        fprintf(_coverage_fout, "1246\n");
        fflush(_coverage_fout);
        }
        check_count = (int )dir->tdir_count;
        {
        fprintf(_coverage_fout, "1247\n");
        fflush(_coverage_fout);
        }
        if ((int )samples < check_count) {
          {
          fprintf(_coverage_fout, "1237\n");
          fflush(_coverage_fout);
          }
          check_count = (int )samples;
        } else {
          {
          fprintf(_coverage_fout, "1238\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1248\n");
        fflush(_coverage_fout);
        }
        i = (unsigned short)1;
        {
        fprintf(_coverage_fout, "1249\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "1243\n");
          fflush(_coverage_fout);
          }
          if ((int )i < check_count) {
            {
            fprintf(_coverage_fout, "1239\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "1244\n");
          fflush(_coverage_fout);
          }
          if (*(v + i) != *(v + 0)) {
            {
            fprintf(_coverage_fout, "1240\n");
            fflush(_coverage_fout);
            }
            tmp___0 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
            {
            fprintf(_coverage_fout, "1241\n");
            fflush(_coverage_fout);
            }
            TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                         "Cannot handle different per-sample values for field \"%s\"",
                         tmp___0->field_name);
            goto bad;
          } else {
            {
            fprintf(_coverage_fout, "1242\n");
            fflush(_coverage_fout);
            }

          }
          {
          fprintf(_coverage_fout, "1245\n");
          fflush(_coverage_fout);
          }
          i = (uint16 )((int )i + 1);
        }
        {
        fprintf(_coverage_fout, "1250\n");
        fflush(_coverage_fout);
        }
        *pl = *(v + 0);
        {
        fprintf(_coverage_fout, "1251\n");
        fflush(_coverage_fout);
        }
        status = 1;
      } else {
        {
        fprintf(_coverage_fout, "1252\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1255\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1263\n");
    fflush(_coverage_fout);
    }
    bad: 
    if (v) {
      {
      fprintf(_coverage_fout, "1258\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )v != (unsigned int )(buf)) {
        {
        fprintf(_coverage_fout, "1256\n");
        fflush(_coverage_fout);
        }
        _TIFFfree((void *)v);
      } else {
        {
        fprintf(_coverage_fout, "1257\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1259\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1264\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1269\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , long nstrips ,
                               uint32 **lpp ) 
{ register uint32 *lp ;
  int status ;
  uint32 *tmp ;
  tdata_t tmp___0 ;
  uint16 *dp ;
  tdata_t tmp___1 ;
  int i ;
  uint32 *dp___0 ;
  tdata_t tmp___2 ;
  int i___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1311\n");
  fflush(_coverage_fout);
  }
  CheckDirCount(tif, dir, (unsigned int )nstrips);
  {
  fprintf(_coverage_fout, "1312\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )*lpp == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "1272\n");
    fflush(_coverage_fout);
    }
    tmp___0 = _TIFFCheckMalloc(tif, (unsigned int )nstrips, sizeof(uint32 ),
                               "for strip array");
    {
    fprintf(_coverage_fout, "1273\n");
    fflush(_coverage_fout);
    }
    tmp = (uint32 *)tmp___0;
    {
    fprintf(_coverage_fout, "1274\n");
    fflush(_coverage_fout);
    }
    *lpp = tmp;
    {
    fprintf(_coverage_fout, "1275\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )tmp == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "1270\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "1271\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1276\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1313\n");
  fflush(_coverage_fout);
  }
  lp = *lpp;
  {
  fprintf(_coverage_fout, "1314\n");
  fflush(_coverage_fout);
  }
  _TIFFmemset((void *)lp, 0,
              (int )((unsigned long )sizeof(uint32 ) * (unsigned long )nstrips));
  {
  fprintf(_coverage_fout, "1315\n");
  fflush(_coverage_fout);
  }
  if ((int )dir->tdir_type == 3) {
    {
    fprintf(_coverage_fout, "1287\n");
    fflush(_coverage_fout);
    }
    tmp___1 = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(uint16 ),
                               "to fetch strip tag");
    {
    fprintf(_coverage_fout, "1288\n");
    fflush(_coverage_fout);
    }
    dp = (uint16 *)tmp___1;
    {
    fprintf(_coverage_fout, "1289\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )dp == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "1277\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "1278\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1290\n");
    fflush(_coverage_fout);
    }
    status = TIFFFetchShortArray(tif, dir, dp);
    {
    fprintf(_coverage_fout, "1291\n");
    fflush(_coverage_fout);
    }
    if (status != 0) {
      {
      fprintf(_coverage_fout, "1284\n");
      fflush(_coverage_fout);
      }
      i = 0;
      {
      fprintf(_coverage_fout, "1285\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1281\n");
        fflush(_coverage_fout);
        }
        if ((long )i < nstrips) {
          {
          fprintf(_coverage_fout, "1280\n");
          fflush(_coverage_fout);
          }
          if (i < (int )dir->tdir_count) {
            {
            fprintf(_coverage_fout, "1279\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1282\n");
        fflush(_coverage_fout);
        }
        *(lp + i) = (unsigned int )*(dp + i);
        {
        fprintf(_coverage_fout, "1283\n");
        fflush(_coverage_fout);
        }
        i ++;
      }
    } else {
      {
      fprintf(_coverage_fout, "1286\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1292\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)((char *)dp));
  } else {
    {
    fprintf(_coverage_fout, "1310\n");
    fflush(_coverage_fout);
    }
    if (nstrips != (long )((int )dir->tdir_count)) {
      {
      fprintf(_coverage_fout, "1303\n");
      fflush(_coverage_fout);
      }
      tmp___2 = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(uint32 ),
                                 "to fetch strip tag");
      {
      fprintf(_coverage_fout, "1304\n");
      fflush(_coverage_fout);
      }
      dp___0 = (uint32 *)tmp___2;
      {
      fprintf(_coverage_fout, "1305\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )dp___0 == (unsigned int )((void *)0)) {
        {
        fprintf(_coverage_fout, "1293\n");
        fflush(_coverage_fout);
        }
        return (0);
      } else {
        {
        fprintf(_coverage_fout, "1294\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1306\n");
      fflush(_coverage_fout);
      }
      status = TIFFFetchLongArray(tif, dir, dp___0);
      {
      fprintf(_coverage_fout, "1307\n");
      fflush(_coverage_fout);
      }
      if (status != 0) {
        {
        fprintf(_coverage_fout, "1300\n");
        fflush(_coverage_fout);
        }
        i___0 = 0;
        {
        fprintf(_coverage_fout, "1301\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "1297\n");
          fflush(_coverage_fout);
          }
          if ((long )i___0 < nstrips) {
            {
            fprintf(_coverage_fout, "1296\n");
            fflush(_coverage_fout);
            }
            if (i___0 < (int )dir->tdir_count) {
              {
              fprintf(_coverage_fout, "1295\n");
              fflush(_coverage_fout);
              }

            } else {
              break;
            }
          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "1298\n");
          fflush(_coverage_fout);
          }
          *(lp + i___0) = *(dp___0 + i___0);
          {
          fprintf(_coverage_fout, "1299\n");
          fflush(_coverage_fout);
          }
          i___0 ++;
        }
      } else {
        {
        fprintf(_coverage_fout, "1302\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1308\n");
      fflush(_coverage_fout);
      }
      _TIFFfree((void *)((char *)dp___0));
    } else {
      {
      fprintf(_coverage_fout, "1309\n");
      fflush(_coverage_fout);
      }
      status = TIFFFetchLongArray(tif, dir, lp);
    }
  }
  {
  fprintf(_coverage_fout, "1316\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static char const   mesg___0[32]  = 
  {      (char const   )'f',      (char const   )'o',      (char const   )'r',      (char const   )' ', 
        (char const   )'\"',      (char const   )'R',      (char const   )'e',      (char const   )'f', 
        (char const   )'e',      (char const   )'r',      (char const   )'e',      (char const   )'n', 
        (char const   )'c',      (char const   )'e',      (char const   )'B',      (char const   )'l', 
        (char const   )'a',      (char const   )'c',      (char const   )'k',      (char const   )'W', 
        (char const   )'h',      (char const   )'i',      (char const   )'t',      (char const   )'e', 
        (char const   )'\"',      (char const   )' ',      (char const   )'a',      (char const   )'r', 
        (char const   )'r',      (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFFetchRefBlackWhite(TIFF *tif , TIFFDirEntry *dir ) 
{ char *cp ;
  int ok ;
  int tmp ;
  tdata_t tmp___0 ;
  float *fp ;
  tdata_t tmp___1 ;
  uint32 i ;
  int tmp___2 ;
  int tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1341\n");
  fflush(_coverage_fout);
  }
  if ((int )dir->tdir_type == 5) {
    {
    fprintf(_coverage_fout, "1317\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFFetchNormalTag(tif, dir);
    {
    fprintf(_coverage_fout, "1318\n");
    fflush(_coverage_fout);
    }
    return (tmp);
  } else {
    {
    fprintf(_coverage_fout, "1319\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1342\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(uint32 ), mesg___0);
  {
  fprintf(_coverage_fout, "1343\n");
  fflush(_coverage_fout);
  }
  cp = (char *)tmp___0;
  {
  fprintf(_coverage_fout, "1344\n");
  fflush(_coverage_fout);
  }
  if (cp) {
    {
    fprintf(_coverage_fout, "1322\n");
    fflush(_coverage_fout);
    }
    tmp___2 = TIFFFetchLongArray(tif, dir, (uint32 *)cp);
    {
    fprintf(_coverage_fout, "1323\n");
    fflush(_coverage_fout);
    }
    if (tmp___2) {
      {
      fprintf(_coverage_fout, "1320\n");
      fflush(_coverage_fout);
      }
      tmp___3 = 1;
    } else {
      {
      fprintf(_coverage_fout, "1321\n");
      fflush(_coverage_fout);
      }
      tmp___3 = 0;
    }
  } else {
    {
    fprintf(_coverage_fout, "1324\n");
    fflush(_coverage_fout);
    }
    tmp___3 = 0;
  }
  {
  fprintf(_coverage_fout, "1345\n");
  fflush(_coverage_fout);
  }
  ok = tmp___3;
  {
  fprintf(_coverage_fout, "1346\n");
  fflush(_coverage_fout);
  }
  if (ok != 0) {
    {
    fprintf(_coverage_fout, "1334\n");
    fflush(_coverage_fout);
    }
    tmp___1 = _TIFFCheckMalloc(tif, dir->tdir_count, sizeof(float ), mesg___0);
    {
    fprintf(_coverage_fout, "1335\n");
    fflush(_coverage_fout);
    }
    fp = (float *)tmp___1;
    {
    fprintf(_coverage_fout, "1336\n");
    fflush(_coverage_fout);
    }
    ok = (unsigned int )fp != (unsigned int )((void *)0);
    {
    fprintf(_coverage_fout, "1337\n");
    fflush(_coverage_fout);
    }
    if (ok != 0) {
      {
      fprintf(_coverage_fout, "1329\n");
      fflush(_coverage_fout);
      }
      i = 0U;
      {
      fprintf(_coverage_fout, "1330\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1326\n");
        fflush(_coverage_fout);
        }
        if (i < dir->tdir_count) {
          {
          fprintf(_coverage_fout, "1325\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1327\n");
        fflush(_coverage_fout);
        }
        *(fp + i) = (float )*((uint32 *)cp + i);
        {
        fprintf(_coverage_fout, "1328\n");
        fflush(_coverage_fout);
        }
        i ++;
      }
      {
      fprintf(_coverage_fout, "1331\n");
      fflush(_coverage_fout);
      }
      ok = TIFFSetField(tif, (unsigned int )dir->tdir_tag, fp);
      {
      fprintf(_coverage_fout, "1332\n");
      fflush(_coverage_fout);
      }
      _TIFFfree((void *)((char *)fp));
    } else {
      {
      fprintf(_coverage_fout, "1333\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1338\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1347\n");
  fflush(_coverage_fout);
  }
  if (cp) {
    {
    fprintf(_coverage_fout, "1339\n");
    fflush(_coverage_fout);
    }
    _TIFFfree((void *)cp);
  } else {
    {
    fprintf(_coverage_fout, "1340\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1348\n");
  fflush(_coverage_fout);
  }
  return (ok);
}
}
static void ChopUpSingleUncompressedStrip(TIFF *tif ) 
{ register TIFFDirectory *td ;
  uint32 bytecount ;
  uint32 offset ;
  tsize_t rowbytes ;
  tsize_t tmp ;
  tsize_t stripbytes ;
  tstrip_t strip ;
  tstrip_t nstrips ;
  tstrip_t rowsperstrip ;
  uint32 *newcounts ;
  uint32 *newoffsets ;
  tdata_t tmp___0 ;
  tdata_t tmp___1 ;
  tstrip_t tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2006-03-03-a72cf60-0a36d7f/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1378\n");
  fflush(_coverage_fout);
  }
  td = & tif->tif_dir;
  {
  fprintf(_coverage_fout, "1379\n");
  fflush(_coverage_fout);
  }
  bytecount = *(td->td_stripbytecount + 0);
  {
  fprintf(_coverage_fout, "1380\n");
  fflush(_coverage_fout);
  }
  offset = *(td->td_stripoffset + 0);
  {
  fprintf(_coverage_fout, "1381\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFVTileSize(tif, 1U);
  {
  fprintf(_coverage_fout, "1382\n");
  fflush(_coverage_fout);
  }
  rowbytes = tmp;
  {
  fprintf(_coverage_fout, "1383\n");
  fflush(_coverage_fout);
  }
  if (rowbytes > 8192) {
    {
    fprintf(_coverage_fout, "1349\n");
    fflush(_coverage_fout);
    }
    stripbytes = rowbytes;
    {
    fprintf(_coverage_fout, "1350\n");
    fflush(_coverage_fout);
    }
    rowsperstrip = 1U;
  } else {
    {
    fprintf(_coverage_fout, "1354\n");
    fflush(_coverage_fout);
    }
    if (rowbytes > 0) {
      {
      fprintf(_coverage_fout, "1351\n");
      fflush(_coverage_fout);
      }
      rowsperstrip = (unsigned int )(8192 / rowbytes);
      {
      fprintf(_coverage_fout, "1352\n");
      fflush(_coverage_fout);
      }
      stripbytes = (int )((tstrip_t )rowbytes * rowsperstrip);
    } else {
      {
      fprintf(_coverage_fout, "1353\n");
      fflush(_coverage_fout);
      }
      return;
    }
  }
  {
  fprintf(_coverage_fout, "1384\n");
  fflush(_coverage_fout);
  }
  if (rowsperstrip >= td->td_rowsperstrip) {
    {
    fprintf(_coverage_fout, "1355\n");
    fflush(_coverage_fout);
    }
    return;
  } else {
    {
    fprintf(_coverage_fout, "1356\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1385\n");
  fflush(_coverage_fout);
  }
  nstrips = (bytecount + ((unsigned int )stripbytes - 1U)) / (unsigned int )stripbytes;
  {
  fprintf(_coverage_fout, "1386\n");
  fflush(_coverage_fout);
  }
  if (nstrips == 0U) {
    {
    fprintf(_coverage_fout, "1357\n");
    fflush(_coverage_fout);
    }
    return;
  } else {
    {
    fprintf(_coverage_fout, "1358\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1387\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFCheckMalloc(tif, nstrips, sizeof(uint32 ),
                             "for chopped \"StripByteCounts\" array");
  {
  fprintf(_coverage_fout, "1388\n");
  fflush(_coverage_fout);
  }
  newcounts = (uint32 *)tmp___0;
  {
  fprintf(_coverage_fout, "1389\n");
  fflush(_coverage_fout);
  }
  tmp___1 = _TIFFCheckMalloc(tif, nstrips, sizeof(uint32 ),
                             "for chopped \"StripOffsets\" array");
  {
  fprintf(_coverage_fout, "1390\n");
  fflush(_coverage_fout);
  }
  newoffsets = (uint32 *)tmp___1;
  {
  fprintf(_coverage_fout, "1391\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )newcounts == (unsigned int )((void *)0)) {
    goto _L;
  } else {
    {
    fprintf(_coverage_fout, "1367\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )newoffsets == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "1363\n");
      fflush(_coverage_fout);
      }
      _L: /* CIL Label */ 
      if ((unsigned int )newcounts != (unsigned int )((void *)0)) {
        {
        fprintf(_coverage_fout, "1359\n");
        fflush(_coverage_fout);
        }
        _TIFFfree((void *)newcounts);
      } else {
        {
        fprintf(_coverage_fout, "1360\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1364\n");
      fflush(_coverage_fout);
      }
      if ((unsigned int )newoffsets != (unsigned int )((void *)0)) {
        {
        fprintf(_coverage_fout, "1361\n");
        fflush(_coverage_fout);
        }
        _TIFFfree((void *)newoffsets);
      } else {
        {
        fprintf(_coverage_fout, "1362\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1365\n");
      fflush(_coverage_fout);
      }
      return;
    } else {
      {
      fprintf(_coverage_fout, "1366\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "1392\n");
  fflush(_coverage_fout);
  }
  strip = 0U;
  {
  fprintf(_coverage_fout, "1393\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1371\n");
    fflush(_coverage_fout);
    }
    if (strip < nstrips) {
      {
      fprintf(_coverage_fout, "1368\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1372\n");
    fflush(_coverage_fout);
    }
    if (stripbytes > (int )bytecount) {
      {
      fprintf(_coverage_fout, "1369\n");
      fflush(_coverage_fout);
      }
      stripbytes = (int )bytecount;
    } else {
      {
      fprintf(_coverage_fout, "1370\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1373\n");
    fflush(_coverage_fout);
    }
    *(newcounts + strip) = (unsigned int )stripbytes;
    {
    fprintf(_coverage_fout, "1374\n");
    fflush(_coverage_fout);
    }
    *(newoffsets + strip) = offset;
    {
    fprintf(_coverage_fout, "1375\n");
    fflush(_coverage_fout);
    }
    offset += (uint32 )stripbytes;
    {
    fprintf(_coverage_fout, "1376\n");
    fflush(_coverage_fout);
    }
    bytecount -= (uint32 )stripbytes;
    {
    fprintf(_coverage_fout, "1377\n");
    fflush(_coverage_fout);
    }
    strip ++;
  }
  {
  fprintf(_coverage_fout, "1394\n");
  fflush(_coverage_fout);
  }
  tmp___2 = nstrips;
  {
  fprintf(_coverage_fout, "1395\n");
  fflush(_coverage_fout);
  }
  td->td_nstrips = tmp___2;
  {
  fprintf(_coverage_fout, "1396\n");
  fflush(_coverage_fout);
  }
  td->td_stripsperimage = tmp___2;
  {
  fprintf(_coverage_fout, "1397\n");
  fflush(_coverage_fout);
  }
  TIFFSetField(tif, 278U, rowsperstrip);
  {
  fprintf(_coverage_fout, "1398\n");
  fflush(_coverage_fout);
  }
  _TIFFfree((void *)td->td_stripbytecount);
  {
  fprintf(_coverage_fout, "1399\n");
  fflush(_coverage_fout);
  }
  _TIFFfree((void *)td->td_stripoffset);
  {
  fprintf(_coverage_fout, "1400\n");
  fflush(_coverage_fout);
  }
  td->td_stripbytecount = newcounts;
  {
  fprintf(_coverage_fout, "1401\n");
  fflush(_coverage_fout);
  }
  td->td_stripoffset = newoffsets;
  {
  fprintf(_coverage_fout, "1402\n");
  fflush(_coverage_fout);
  }
  td->td_stripbytecountsorted = 1;
  {
  fprintf(_coverage_fout, "1403\n");
  fflush(_coverage_fout);
  }
  return;
}
}
